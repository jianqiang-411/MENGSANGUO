#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"
#include "help.h"
#include "makeNewUser.h"
#include "score.h"
#include "choiceAuthor.h"

using namespace cocos2d;
using namespace CocosDenshion;

CCScene* HelloWorld::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    HelloWorld *layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
        return false;
    }
      
  //get the winsize
    CCSize size = CCDirector::sharedDirector()->getWinSize();
 
  //create the bg for menu
    CCSprite* bgMenu = CCSprite::create("bg.png");
    bgMenu->setPosition(ccp(size.width*1/2, size.height*1/2));
    this->addChild(bgMenu);
  
  //create the menu of play
    CCMenuItemImage* itemPlay = CCMenuItemImage::create("start.png", "start.png",this,menu_selector(HelloWorld::playIsPressed));
    itemPlay->setPosition(ccp(0, 55));
    
  //create the menu of score
    CCMenuItemImage* itemScore = CCMenuItemImage::create("score.png", "score.png",this,menu_selector(HelloWorld::scoreIsPressed));
    itemScore->setPosition(ccp(0,5));
    
    //create the menu of help
    CCMenuItemImage* itemHelp = CCMenuItemImage::create("help.png", "help.png",this,menu_selector(HelloWorld::helpIsPressed));
    itemHelp->setPosition(ccp(0, -45));
    
  //bgmusic button
    
   itemMusic = CCMenuItemImage::create("musicOFF.png", "musicON.png",this,menu_selector(HelloWorld::musicIsPressed));
    itemMusic->setPosition(ccp(200,-135));

    
    
    // add a "close" icon to exit the progress. it's an autorelease object
    CCMenuItemImage *Itemquit = CCMenuItemImage::create( "quit.png","quit.png",this,menu_selector(HelloWorld::quitIsPressed));
    Itemquit->setPosition(ccp(0, -95));
    
  //add the 5 editmenus into the menu
    CCMenu* menu = CCMenu::create(itemPlay,itemScore,itemHelp,Itemquit,itemMusic, NULL);
 //  menu->setPosition(ccp(240, 120));
    addChild(menu);
    
  //particle
    CCTexture2D* texture = CCTextureCache::sharedTextureCache()->addImage("steam.png");
    CCParticleBatchNode* particleNode =CCParticleBatchNode::createWithTexture(texture);
    for (int i =0 ; i<50; i++) {
        CCParticleSystem* particleSyetem = CCParticleSmoke::create();
        particleSyetem->setTexture(texture);
        particleSyetem->setPosition(ccp(i*80,0));
        particleNode->addChild(particleSyetem);
    }
    
    for (int i =0 ; i<50; i++) {
        CCParticleSystem* particleSyetem = CCParticleSmoke::create();
        particleSyetem->setTexture(texture);
        particleSyetem->setPosition(ccp(i*120,310));
        particleNode->addChild(particleSyetem);
    }
    addChild(particleNode);
    
    CCSprite * temp = CCSprite::create("msg.png");
    temp->setScale(0.6);
    temp->setPosition(ccp(240,275));
    addChild(temp);

 
    return true;
}



//change into play scene
void HelloWorld:: playIsPressed() {
    CCDirector::sharedDirector()->replaceScene(CCTransitionFade::create(0.5, choiceAuthor::scene()));
    
    
}
void HelloWorld:: scoreIsPressed() {
    CCDirector::sharedDirector()->replaceScene(CCTransitionJumpZoom::create(0.5,score::scene()));
    
}
void HelloWorld:: helpIsPressed() {
    CCDirector::sharedDirector()->replaceScene(CCTransitionFadeBL::create(0.5, help::scene()));
        
}

static int count=0;
void HelloWorld::musicIsPressed() {
    SimpleAudioEngine::sharedEngine()->playBackgroundMusic("gameMusic.mp3", true);
    SimpleAudioEngine::sharedEngine()->setBackgroundMusicVolume(0.5);

    if (count%2==1) {
        SimpleAudioEngine::sharedEngine()->pauseBackgroundMusic();
        itemMusic->setNormalImage(CCSprite::create("musicOFF.png"));
        //background music
        
               
    }
    if (count%2==0) {
        SimpleAudioEngine::sharedEngine()->resumeBackgroundMusic();
        itemMusic->setNormalImage(CCSprite::create("musicON.png"));
    
    }
    count++;
        

    
}

void HelloWorld:: quitIsPressed()
{
   CCDirector::sharedDirector()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
  exit(0);
#endif
}
