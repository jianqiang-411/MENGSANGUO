//
//  author.cpp
//  MengSanGuo
//
//  Created by 尚德机构 on 13-7-22.
//
//

#include "author.h"
#include "HelloWorldScene.h"
#include "help.h"

using namespace cocos2d;

CCScene* author::scene()
{
    CCScene *scene = CCScene::create();
    author *layer = author::create();
    scene->addChild(layer);
    return scene;
}

bool author::init()
{
    if (!CCLayer::init()) {
        return false;
    }
    //get the screen size
    CCSize size = CCDirector::sharedDirector()->getWinSize();
    //background
    CCSprite* sp = CCSprite::create("helpbg2.png");
    sp->setPosition(ccp(size.width/2.0f, size.height/2.0f));
    addChild(sp);
    
    //add a buttun to change into the menu scene
    CCMenuItemImage *Itemquit = CCMenuItemImage::create( "back.png","back.png",this,menu_selector(author::backMenu));
    Itemquit->setPosition(ccp(40.0f, 40.0f));
    
    // create menu, it's an autorelease object
    CCMenu* pMenu = CCMenu::create(Itemquit, NULL);
    pMenu->setPosition( CCPointZero );
    this->addChild(pMenu, 1);
    
    
    //－－－－－－CCLabelAtlas
    
    CCLabelTTF* label1 = CCLabelTTF::create();
    //设置字体大小
    label1->setFontSize(28);
    label1->setColor(ccc3(255, 66, 77));
    //设置字符串
    label1->setString("制作小组");
    label1->setPosition( ccp(120,230) );
    this->addChild(label1);
    
 
    CCLabelTTF* label2 = CCLabelTTF::create("钱康\n聂鑫\n马梓元\n殷王辉", "Helvetica", 20);
    label2->setPosition(ccp(200,130));
    //设置字体颜色
    label2->setColor(ccc3(255, 255, 97));
    addChild(label2);
       
    CCTexture2D* texture = CCTextureCache::sharedTextureCache()->addImage("snow.png");
    CCParticleBatchNode* particleNode =CCParticleBatchNode::createWithTexture(texture);
    for (int i =0 ; i<1; i++) {
        CCParticleSystem* particleSyetem = CCParticleFireworks::create();
        particleSyetem->setTexture(texture);
        particleSyetem->setPosition(ccp(420+i*40,10));
        particleNode->addChild(particleSyetem);
    }
    
    addChild(particleNode);
    
    
    
        return true;
}



void author::backMenu()
{
    CCDirector::sharedDirector()->replaceScene(CCTransitionPageTurn::create(0.5, help::scene(), true));
}