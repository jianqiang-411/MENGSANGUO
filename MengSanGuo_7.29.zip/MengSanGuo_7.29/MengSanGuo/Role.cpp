//
//  Role.cpp
//  Team
//
//  Created by naxx on 13-7-24.
//
//

#include "Role.h"
CCScene* RoleTablelView::scene()
{
    CCScene *scene = CCScene::create();
    RoleTablelView *layer = RoleTablelView::create();
    scene->addChild(layer);
    return scene;
}
bool RoleTablelView::init()
{
    bool pRet = false;
    do {
        CC_BREAK_IF(!CCLayer::init());
        
        CCTableView *pTableView = CCTableView::create(this, CCSizeMake(480, 320));
        pTableView->setDirection(kCCScrollViewDirectionVertical);
        pTableView->setPosition(CCPointZero);
        pTableView->setDelegate(this);
        pTableView->setVerticalFillOrder(kCCTableViewFillTopDown);
        this->addChild(pTableView);
        pTableView->reloadData();
        
        
//        CCDirector::sharedDirector()->getTouchDispatcher()->addTargetedDelegate(this, 2, true);
        pRet = true;
    } while (0);
    return pRet;
    
}
void RoleTablelView::scrollViewDidScroll(cocos2d::extension::CCScrollView* view)
{
    
}
void RoleTablelView::scrollViewDidZoom(cocos2d::extension::CCScrollView* view)
{
    
}
CCSize RoleTablelView::cellSizeForTable(CCTableView *table)
{
    return CCSizeMake(320, 20);
}
CCTableViewCell* RoleTablelView::tableCellAtIndex(CCTableView *table, unsigned int idx)
{
    CCString *pString = CCString::createWithFormat("%d", idx);
    CCTableViewCell *pCell = table->dequeueCell();
    if (!pCell) {
        pCell = new CCTableViewCell();
        pCell->autorelease();
//        CCSprite *pSprite = CCSprite::create("listitem.png");
//        pSprite->setScale(0.5f);
//        pSprite->setAnchorPoint(CCPointZero);
//		pSprite->setPosition(CCPointZero);
//        pCell->addChild(pSprite);
        
        CCLabelTTF *pLabel = CCLabelTTF::create(pString->getCString(), "Arial", 30);
        pLabel->setPosition(CCPointZero);
		pLabel->setAnchorPoint(CCPointZero);
        pLabel->setTag(123);
        pCell->addChild(pLabel);
    }
    else
    {
        CCLabelTTF *pLabel = (CCLabelTTF*)pCell->getChildByTag(123);
        pLabel->setString(pString->getCString());
    }
    
    
    return pCell;
}

unsigned int RoleTablelView::numberOfCellsInTableView(CCTableView *table)
{
    return 10;
}
void RoleTablelView::tableCellTouched(CCTableView* table, CCTableViewCell* cell)
{
    CCLog("cell touched at index: %i", cell->getIdx());
}