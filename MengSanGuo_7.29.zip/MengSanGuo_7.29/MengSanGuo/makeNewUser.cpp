//
//  makeNewUser.cpp
//  MengSanGuo
//
//  Created by 尚德机构 on 13-7-19.
//
//

#include "makeNewUser.h"
#include "HelloWorldScene.h"
#include "SimpleAudioEngine.h"
#include "choiceAuthor.h"
#include "MSGWorld.h"
using namespace cocos2d;
using namespace CocosDenshion;

CCScene* makeNewUser::scene()
{
    CCScene *scene = CCScene::create();
    makeNewUser *layer = makeNewUser::create();
    scene->addChild(layer);
    return scene;
}

bool makeNewUser::init()
{
    if ( !CCLayer::init() )
    {
        return false;
    }
    
    
    //get the screen size
    CCSize size = CCDirector::sharedDirector()->getWinSize();

    //background
    CCSprite* sp = CCSprite::create("makeNewUserbg.png");
    sp->setPosition(ccp(size.width/2.0f, size.height/2.0f));
    addChild(sp);

    
    CCScale9Sprite * sacel9Spr = CCScale9Sprite::create("makeNewUser.png");
   
    CCEditBox* box = CCEditBox::create(CCSizeMake(150, 30), sacel9Spr);
    box->setPlaceHolder("请为角色起名");
    box->setPosition(ccp(size.width/2.0f, size.height/2.0f));
    addChild(box);
    //接口绑定
    box->setDelegate(this);
    
    
    //add a "sure" button 
    CCMenuItemImage* itemSure = CCMenuItemImage::create("sure.png", "sure.png",this,menu_selector(makeNewUser::sureIsPressed));
    itemSure->setPosition(ccp(0, -75));
    
    
    //add a buttun to change into the menu scene
    CCMenuItemImage *Itemquit = CCMenuItemImage::create( "back.png","back.png",this,menu_selector(makeNewUser:: backMenu));
    Itemquit->setPosition(ccp(40.0f, 40.0f));
    
    //
    //    // create menu, it's an autorelease object
    CCMenu* pMenu = CCMenu::create(Itemquit, NULL);
    pMenu->setPosition( CCPointZero );
    this->addChild(pMenu, 1);
    
    
    CCMenu* menu = CCMenu::create(itemSure, NULL);
    addChild(menu);
    
    
    return true;
}


//开始进入编辑
void makeNewUser::editBoxEditingDidBegin(cocos2d::extension::CCEditBox* editBox){
    CCLOG("Start Edit");
}

//结束编辑
void makeNewUser:: editBoxEditingDidEnd(cocos2d::extension::CCEditBox* editBox){
    CCLOG("End Edit");
}

//编辑框文本改变
void makeNewUser:: editBoxTextChanged(cocos2d::extension::CCEditBox* editBox, const std::string& text){
    CCLOG("TextChanged");
    CCUserDefault::sharedUserDefault()->setStringForKey("name", text);
}

//当触发return后的回调函数
void makeNewUser::editBoxReturn(cocos2d::extension::CCEditBox* editBox){
    CCLOG("editBoxReturn");
    

}


//game is on
void makeNewUser:: sureIsPressed() {
    CCDirector::sharedDirector()->replaceScene(CCTransitionFadeBL::create(0.5, MSGWorld::scene()));
    
}


void makeNewUser::backMenu()
{
    CCDirector::sharedDirector()->replaceScene(CCTransitionPageTurn::create(0.5, choiceAuthor::scene(), true));
}