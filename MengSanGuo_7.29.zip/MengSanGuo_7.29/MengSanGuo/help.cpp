//
//  help.cpp
//  MengSanGuo
//
//  Created by 尚德机构 on 13-7-18.
//
//

#include "help.h"
#include "HelloWorldScene.h"
#include "author.h"

using namespace cocos2d;

CCScene* help::scene()
{
    CCScene *scene = CCScene::create();
    help *layer = help::create();
    scene->addChild(layer);
    return scene;
}

bool help::init()
{
    if (!CCLayer::init()) {
        return false;
    }
    //get the screen size
    CCSize size = CCDirector::sharedDirector()->getWinSize();
    //background
    CCSprite* sp = CCSprite::create("helpbg.png");
    sp->setPosition(ccp(size.width/2.0f, size.height/2.0f));
    addChild(sp);
    
    //add a buttun to change into the menu scene
       CCMenuItemImage *Itemquit = CCMenuItemImage::create( "back.png","back.png",this,menu_selector(help::backMenu));
    Itemquit->setPosition(ccp(40.0f, 40.0f));
    
    // create menu, it's an autorelease object
    CCMenu* pMenu = CCMenu::create(Itemquit, NULL);
    pMenu->setPosition( CCPointZero );
    this->addChild(pMenu, 1);
    
    CCLabelBMFont* label1 = CCLabelBMFont::create("GameInfo", "testChinese.fnt");
    label1->setPosition(ccp(240,255));
    addChild(label1);
    
    //－－－－－－CCLabelTTF
    CCLabelTTF* pLabel = CCLabelTTF::create("游戏以三国历史为背景，用Q版画面打造了\n一个全新的三国世界。对剧情人物进行了\n重新包装，三国英雄同样可以幽默时尚。", "Thonburi", 18);
    pLabel->setPosition( ccp(240,160) );
    pLabel->setColor(ccWHITE);
    this->addChild(pLabel);
     
    //create the menu for author
    CCMenuItemImage* itemAuthor = CCMenuItemImage::create("author.png", "author.png",this,menu_selector(help::authorIsPressed));
    itemAuthor->setPosition(ccp(150, -105));
    

    CCMenu* menu = CCMenu::create(itemAuthor, NULL);
    addChild(menu);
    
    
    CCTexture2D* texture = CCTextureCache::sharedTextureCache()->addImage("stars.png");
    CCParticleBatchNode* particleNode =CCParticleBatchNode::createWithTexture(texture);
    for (int i =0 ; i<1; i++) {
        CCParticleSystem* particleSyetem = CCParticleRain::create();
        particleSyetem->setTexture(texture);
        particleSyetem->setPosition(ccp(200+i*20,320));
        particleNode->addChild(particleSyetem);
    }
    addChild(particleNode);
    
    return true;
}

//change into play scene
void help:: authorIsPressed() {
    CCDirector::sharedDirector()->replaceScene(CCTransitionFadeDown::create(0.5, author::scene()));
}


void help::backMenu()
{
    CCDirector::sharedDirector()->replaceScene(CCTransitionPageTurn::create(0.5, HelloWorld::scene(), true));
}