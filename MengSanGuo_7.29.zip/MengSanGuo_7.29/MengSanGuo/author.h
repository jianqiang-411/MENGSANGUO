//
//  author.h
//  MengSanGuo
//
//  Created by 尚德机构 on 13-7-22.
//
//

#ifndef __MengSanGuo__author__
#define __MengSanGuo__author__

#include <iostream>
#include "cocos2d.h"
class author : public cocos2d::CCLayer
{
public:
    virtual bool init();
    static cocos2d::CCScene* scene();
    CREATE_FUNC(author);
    
private:
    void backMenu();
   

};
#endif /* defined(__MengSanGuo__author__) */
