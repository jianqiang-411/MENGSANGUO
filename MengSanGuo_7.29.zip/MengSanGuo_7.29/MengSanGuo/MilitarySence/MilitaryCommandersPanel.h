//
//  MilitaryCommandersPanel.h
//  mySanGuo
//
//  Created by macbook on 13-7-25.
//
//

#ifndef __mySanGuo__MilitaryCommandersPanel__
#define __mySanGuo__MilitaryCommandersPanel__

#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"

using namespace cocos2d;
using namespace extension;

class MilitaryCommandersPanel:public CCLayer,public CCTableViewDataSource,public CCTableViewDelegate
{
public:
    CCTableView *myTableView;
    CCArray *myTableInfos;
    CCArray *myTableDetailInfosID;
    CCArray *myTableDetailInfosName;
    CCSprite *background1;
    CCLabelTTF *box1_name;
    CCLabelTTF *bg2_level;
    CCSprite *bg2_classIMG;
    CCLabelTTF *bg2_class;
    CCLabelTTF *bg2_expV;
    CCLabelTTF *bg2_hpV;
    CCLabelTTF *bg2_moveV;
    CCLabelTTF *bg2_damageV;
    CCLabelTTF *bg2_rangeV;
    CCSprite *personIMG;
    CCArray *personIMGFrames;
    
    virtual bool init();
    
    static CCScene* scene();
    
    CREATE_FUNC(MilitaryCommandersPanel);
    void myUpdate();
    void backToHome();
    
    virtual CCSize cellSizeForTable(CCTableView *table);
    virtual CCTableViewCell* tableCellAtIndex(CCTableView *table, unsigned int idx);
    virtual unsigned int numberOfCellsInTableView(CCTableView *table);
    virtual void tableCellTouched(CCTableView* table, CCTableViewCell* cell);
    virtual void scrollViewDidScroll(CCScrollView* view){};
    virtual void scrollViewDidZoom(CCScrollView* view){};
    
    virtual void onExit();
};

#endif /* defined(__mySanGuo__MilitaryCommandersPanel__) */
