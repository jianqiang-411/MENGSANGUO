//
//  MilitaryCommandersPanel.cpp
//  mySanGuo
//
//  Created by macbook on 13-7-25.
//
//

#include "MilitaryCommandersPanel.h"
#include "SaveAndLoad.h"
#include "Actions.h"
#include "MSGWorld.h"

CCScene* MilitaryCommandersPanel::scene()
{
    CCScene *scene = CCScene::create();
    MilitaryCommandersPanel *layer = MilitaryCommandersPanel::create();
    scene->addChild(layer);
    return scene;
}

bool MilitaryCommandersPanel::init()
{
    if ( !CCLayer::init() )
    {
        return false;
    }
    //背景
    CCSprite *background=CCSprite::create("yuxu.png");
    this->addChild(background);
    //返回按钮
    CCMenuItemSprite *back=CCMenuItemSprite::create(CCSprite::create("back.png"), CCSprite::create("back.png"), this, menu_selector(MilitaryCommandersPanel::backToHome));
    back->setPosition(ccp(430,50));
    CCMenu *myBack=CCMenu::create(back,NULL);
    myBack->setPosition(CCPointZero);
    this->addChild(myBack,3);
    //表格底背景
    background1=CCSprite::create("10-1.png");
    background1->setPosition(ccp(240,215));
    background1->setScaleX(0.77);
    background1->setScaleY(0.667);
    this->addChild(background1,1);
    //武将具体属性框背景
    CCSprite *background2=CCSprite::create("8-2.png");
    background2->setPosition(ccp(200, 72));
    background2->setScaleY(0.75);
    this->addChild(background2,1);
    //武将图片底框
    CCSprite *box1=CCSprite::create("box-1.png");
    box1->setPosition(ccp(58, 70));
    box1->setScale(0.6);
    this->addChild(box1,1);
    //武将技能底框
    CCSprite *box2_1=CCSprite::create("box-2.png");
    box2_1->setPosition(ccp(240, 60));
    box2_1->setScaleX(0.55);
    box2_1->setScaleY(0.6);
    this->addChild(box2_1,1);
    CCSprite *box2_2=CCSprite::create("box-2.png");
    box2_2->setPosition(ccp(290, 60));
    box2_2->setScaleX(0.55);
    box2_2->setScaleY(0.6);
    this->addChild(box2_2,1);
    CCSprite *box2_3=CCSprite::create("box-2.png");
    box2_3->setPosition(ccp(340, 60));
    box2_3->setScaleX(0.55);
    box2_3->setScaleY(0.6);
    this->addChild(box2_3,1);
    //武将姓名
    box1_name=CCLabelTTF::create("未选择", "Arial", 12);
    box1_name->setColor(ccc3(255, 0, 0));
    box1_name->setPosition(ccp(51, 94));
    this->addChild(box1_name,2);
    //武将等级
    bg2_level=CCLabelTTF::create("Lv 0", "Arial", 12);
    bg2_level->setColor(ccc3(0, 0, 0));
    bg2_level->setPosition(ccp(115, 90));
    this->addChild(bg2_level,2);
    //武将职业
    bg2_class=CCLabelTTF::create("无", "Arial", 12);
    bg2_class->setColor(ccc3(50, 50, 50));
    bg2_class->setPosition(ccp(180, 90));
    this->addChild(bg2_class,2);
    //武将经验标签
    CCLabelTTF *bg2_exp=CCLabelTTF::create("经验", "Arial", 12);
    bg2_exp->setColor(ccc3(50, 10, 10));
    bg2_exp->setPosition(ccp(115, 75));
    this->addChild(bg2_exp,2);
    //武将经验数据
    bg2_expV=CCLabelTTF::create("0/0", "Arial", 12);
    bg2_expV->setColor(ccc3(50, 10, 10));
    bg2_expV->setPosition(ccp(170, 75));
    this->addChild(bg2_expV,2);
    //武将血量
    CCSprite *bg2_hp=CCSprite::create("hp.png");
    bg2_hp->setPosition(ccp(115, 60));
    bg2_hp->setScale(0.6);
    this->addChild(bg2_hp,2);
    //武将血量数据
    bg2_hpV=CCLabelTTF::create("0", "Arial", 12);
    bg2_hpV->setColor(ccc3(0, 0, 0));
    bg2_hpV->setPosition(ccp(145, 60));
    this->addChild(bg2_hpV,2);
    //武将机动力标签
    CCSprite *bg2_move=CCSprite::create("move.png");
    bg2_move->setPosition(ccp(180, 60));
    bg2_move->setScale(0.6);
    this->addChild(bg2_move,2);
    //武将机动力数据
    bg2_moveV=CCLabelTTF::create("0", "Arial", 12);
    bg2_moveV->setColor(ccc3(0, 0, 0));
    bg2_moveV->setPosition(ccp(200, 60));
    this->addChild(bg2_moveV,2);
    //武将攻击力标签
    CCSprite *bg2_damage=CCSprite::create("power.png");
    bg2_damage->setPosition(ccp(115, 45));
    bg2_damage->setScale(0.6);
    this->addChild(bg2_damage,2);
    //武将攻击力数据
    bg2_damageV=CCLabelTTF::create("0", "Arial", 12);
    bg2_damageV->setColor(ccc3(0, 0, 0));
    bg2_damageV->setPosition(ccp(145, 45));
    this->addChild(bg2_damageV,2);
    //武将射程标签
    CCSprite *bg2_range=CCSprite::create("range.png");
    bg2_range->setPosition(ccp(180, 45));
    bg2_range->setScale(0.6);
    this->addChild(bg2_range,2);
    //武将射程数据
    bg2_rangeV=CCLabelTTF::create("0", "Arial", 12);
    bg2_rangeV->setColor(ccc3(0, 0, 0));
    bg2_rangeV->setPosition(ccp(200, 45));
    this->addChild(bg2_rangeV,2);
    //武将技能1
    CCLabelTTF *bg2_skill1=CCLabelTTF::create("技能一", "Arial", 12);
    bg2_skill1->setColor(ccc3(0, 0, 0));
    bg2_skill1->setPosition(ccp(240, 88));
    this->addChild(bg2_skill1,2);
    //武将技能2
    CCLabelTTF *bg2_skill2=CCLabelTTF::create("技能二", "Arial", 12);
    bg2_skill2->setColor(ccc3(0, 0, 0));
    bg2_skill2->setPosition(ccp(290, 88));
    this->addChild(bg2_skill2,2);
    //武将技能3
    CCLabelTTF *bg2_skill3=CCLabelTTF::create("必杀技", "Arial", 12);
    bg2_skill3->setColor(ccc3(0, 0, 0));
    bg2_skill3->setPosition(ccp(340, 88));
    this->addChild(bg2_skill3,2);
    
    //人物图片
    //CCTextureCache::sharedTextureCache()->addPVRImage("sanguo.pvr.ccz");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("sanguo.plist");

//    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("sanguo.plist", "sanguo.pvr.ccz");
//    CCSpriteBatchNode *spriteSheet=CCSpriteBatchNode::create("sanguo.pvr.ccz");
//    this->addChild(spriteSheet);
    
    personIMG=CCSprite::create("empty.png");
    personIMG->setPosition(ccp(60, 60));
    this->addChild(personIMG,1);
    
    //表格显示数据
    SaveAndLoad *myCreate=[[SaveAndLoad alloc]init];
    myTableInfos = CCArray::createWithCapacity(10);
    for(int i=1;i<=10;i++){
        if([myCreate searchTestList:i].hasThePerson==1){
            if([myCreate searchTestList:i].personName.length==3)
            {
                myTableInfos->addObject(CCString::createWithFormat("武将名 :  %s               等级:%d          战斗力:%d          职业:%s",[[myCreate searchTestList:i].personName UTF8String],[myCreate searchTestList:i].level,[myCreate searchTestList:i].power,[[myCreate searchTestList:i].personClass UTF8String]));                         
            } else if([myCreate searchTestList:i].personName.length==2){
                myTableInfos->addObject(CCString::createWithFormat("武将名： %s                  等级:%d          战斗力:%d          职业:%s",[[myCreate searchTestList:i].personName UTF8String],[myCreate searchTestList:i].level,[myCreate searchTestList:i].power,[[myCreate searchTestList:i].personClass UTF8String]));
            }
        }
    }
    myTableInfos->retain();
    
    myTableDetailInfosID = CCArray::createWithCapacity(10);
    for(int i=1;i<=10;i++){
        if([myCreate searchTestList:i].hasThePerson==1){
            myTableDetailInfosID->addObject(CCString::createWithFormat("%d",[myCreate searchTestList:i].sqlID));
        }
    }
    myTableDetailInfosID->retain();
    
    myTableDetailInfosName = CCArray::createWithCapacity(10);
    for(int i=1;i<=10;i++){
        if([myCreate searchTestList:i].hasThePerson==1){
            myTableDetailInfosName->addObject(CCString::createWithFormat("%s",[[myCreate searchTestList:i].personName UTF8String]));
        }
    }
    myTableDetailInfosName->retain();
//    //创建表格
    CCTableView *table=CCTableView::create(this, CCSizeMake(430, 142));
    table->setDirection(kCCScrollViewDirectionVertical);
    table->setAnchorPoint(ccp(0,0));
    table->setPosition(ccp(24, 320-32-142));
    table->setDelegate(this);
    table->setVerticalFillOrder(kCCTableViewFillTopDown);
    myTableView=table;
    this->addChild(myTableView,1);
    myTableView->reloadData();
    table->release();
    
    //云图片背景
    CCSprite *background3=CCSprite::create("8-3.png");
    background3->setOpacity(150);
    background3->setPosition(ccp(405,150));
    this->addChild(background3,3);
    
    this->setTouchEnabled(true);
    
    this->schedule(schedule_selector(MilitaryCommandersPanel::myUpdate));
    return true;
}
void MilitaryCommandersPanel::myUpdate()
{
    if (myTableView->getContentOffset().y<=-138.0) {
        background1->initWithFile("10-3.png");
        background1->setPosition(ccp(240,215));
        background1->setScaleX(0.77);
        background1->setScaleY(0.667);
    }
    else if(myTableView->getContentOffset().y>-138.0 && myTableView->getContentOffset().y<0.0){
        background1->initWithFile("10-4.png");
        background1->setPosition(ccp(240,215));
        background1->setScaleX(0.77);
        background1->setScaleY(0.667);
    }
    else {
        background1->initWithFile("10-2.png");
        background1->setPosition(ccp(240,215));
        background1->setScaleX(0.77);
        background1->setScaleY(0.667);
    }
}
void MilitaryCommandersPanel::backToHome()
{

CCDirector::sharedDirector()->replaceScene(CCTransitionFadeBL::create(0.5, MSGWorld::scene()));
}

CCSize MilitaryCommandersPanel::cellSizeForTable(CCTableView *table){
    return CCSizeMake(430, 142/5);
}

CCTableViewCell* MilitaryCommandersPanel::tableCellAtIndex(CCTableView *table, unsigned int idx){
    CCTableViewCell *cell = table->dequeueCell();
    CCString *str=(CCString *)myTableInfos->objectAtIndex(idx);
    if (!cell) {
        // the sprite
        cell = new CCTableViewCell();
        cell->autorelease();
    
        CCLabelTTF *sprite=CCLabelTTF::create(str->getCString(),"Arial", 12);
        sprite->setAnchorPoint(CCPointZero);
        sprite->setPosition(CCPointZero);
        sprite->setColor(ccc3(0, 0, 0));
        sprite->setTag(456);
        cell->addChild(sprite);
    } else {
        CCLabelTTF *sprite=(CCLabelTTF *)cell->getChildByTag(456);
        sprite->setString(str->getCString());
    }
    return cell;
}

unsigned int MilitaryCommandersPanel::numberOfCellsInTableView(CCTableView *table){
    return 10;
}

void MilitaryCommandersPanel::tableCellTouched(CCTableView* table, CCTableViewCell* cell){
    SaveAndLoad *myCreate=[[SaveAndLoad alloc]init];
    
    CCString *personNameS=(CCString *)myTableDetailInfosName->objectAtIndex(cell->getIdx());
    box1_name->setString(personNameS->getCString());
    
    CCString *ccs1=(CCString *)myTableDetailInfosID->objectAtIndex(cell->getIdx());
    int myRow=ccs1->intValue();
    bg2_level->setString(CCString::createWithFormat("Lv %d",[myCreate searchTestList:myRow].level)->getCString());
    bg2_class->setString(CCString::createWithFormat("%s",[[myCreate searchTestList:myRow].personClass UTF8String])->getCString());
    bg2_hpV->setString(CCString::createWithFormat("%d",[myCreate searchTestList:myRow].hp)->getCString());
    bg2_expV->setString(CCString::createWithFormat("%d/100",[myCreate searchTestList:myRow].curEXP-([myCreate searchTestList:myRow].level-1)*100)->getCString());
    bg2_damageV->setString(CCString::createWithFormat("%d",[myCreate searchTestList:myRow].damage)->getCString());
    bg2_moveV->setString(CCString::createWithFormat("%d",[myCreate searchTestList:myRow].movement)->getCString());
    bg2_rangeV->setString(CCString::createWithFormat("%d",[myCreate searchTestList:myRow].range)->getCString());

    //武将职业图片
    bg2_classIMG=CCSprite::create(CCString::createWithFormat("class-%s.png",[[myCreate searchTestList:myRow].personClass UTF8String])->getCString());
    bg2_classIMG->setPosition(ccp(150,90));
    bg2_classIMG->setScale(0.6);
    this->addChild(bg2_classIMG,1);
    //人物图片动画
    personIMG->stopAllActions();
    Actions *myAct=Actions::create();
    personIMG->runAction(myAct->creatWalkAction(CCString::createWithFormat("%s_",[[myCreate searchTestList:myRow].easyName UTF8String])->getCString(), 5, 8));

}



void MilitaryCommandersPanel::onExit()
{
    this->unscheduleAllSelectors();
//    CCLayer::onExit();
}



