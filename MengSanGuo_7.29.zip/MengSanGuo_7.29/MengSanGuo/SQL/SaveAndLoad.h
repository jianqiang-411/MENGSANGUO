//
//  SaveAndLoad.h
//  DemonCastle
//
//  Created by macbook on 13-6-20.
//
//

#import <UIKit/UIKit.h>
#import "/usr/include/sqlite3.h"
@class sqlTestList;
@interface SaveAndLoad : NSObject{
    sqlite3 *db; //声明一个sqlite3数据库
}
@property (nonatomic)sqlite3 *db;
-(BOOL)createTestList:(sqlite3 *)db;//创建数据库
-(BOOL)insertList:(sqlTestList *)List;//插入数据
-(BOOL)saveList:(sqlTestList *)List;//更新数据
-(NSMutableArray*)getTestList;//获取全部数据
-(BOOL)deleteList:(sqlTestList *)deletList;//删除数据
-(sqlTestList*)searchTestList:(int)searchID;//查询数据库，searchID为要查询数据的ID，返回数据为查询到的数据
@end

@interface sqlTestList : NSObject//从头定义了一个类，专门用于存储数据
{
    int sqlID;
    NSString *personName;
    int hasThePerson;
    int level;
    int curEXP;
    int power;
    NSString *personClass;
    int hp;
    int damage;
    int movement;
    int range;
    NSString *skill1,*skill2,*skill3;
    NSString *easyName;
    
}
@property(nonatomic) int sqlID;
@property(nonatomic,retain) NSString *personName;
@property(nonatomic,assign) int hasThePerson;
@property(nonatomic,assign) int level;
@property(nonatomic,assign) int curEXP;
@property(nonatomic,assign) int power;
@property(nonatomic,assign) NSString *personClass;
@property(nonatomic,assign) int hp;
@property(nonatomic,assign) int damage;
@property(nonatomic,assign) int movement;
@property(nonatomic,assign) int range;
@property(nonatomic,retain) NSString *skill1,*skill2,*skill3;
@property(nonatomic,retain) NSString *easyName;

@end
