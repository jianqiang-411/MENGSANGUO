//
//  SaveAndLoad.m
//  DemonCastle
//
//  Created by macbook on 13-6-20.
//
//

#import "SaveAndLoad.h"

@interface SaveAndLoad ()

@end

@implementation SaveAndLoad
@synthesize db;

-(id)init
{
    if(self=[super init]){
        [self checkSQL];
    }
    return self;
}
-(void)checkSQL
{
    if([self searchTestList:1].sqlID!=1)[self initSQL];
    
}
-(void)initSQL
{
    sqlTestList *stl1=[[sqlTestList alloc]init];
    stl1.sqlID=1;stl1.personName=@"刘备";stl1.personClass=@"战士";stl1.easyName=@"lb";
    stl1.level=1;stl1.curEXP=0;stl1.hasThePerson=1;
    stl1.hp=100+50*stl1.level;stl1.damage=20+12*stl1.level;stl1.movement=4;stl1.range=1;
    stl1.power=stl1.hp+stl1.damage*2;
    stl1.skill1=@"";stl1.skill2=@"";stl1.skill3=@"";
    [self insertList:stl1];
    
    sqlTestList *stl2=[[sqlTestList alloc]init];
    stl2.sqlID=2;stl2.personName=@"诸葛亮";stl2.personClass=@"谋士";stl2.easyName=@"zgl";
    stl2.level=1;stl2.curEXP=0;stl2.hasThePerson=1;
    stl2.hp=80+40*stl2.level;stl2.damage=30+14*stl2.level;stl2.movement=1;stl2.range=4;
    stl2.power=stl2.hp+stl2.damage*2;
    stl2.skill1=@"";stl2.skill2=@"";stl2.skill3=@"";
    [self insertList:stl2];
    
    sqlTestList *stl3=[[sqlTestList alloc]init];
    stl3.sqlID=3;stl3.personName=@"关羽";stl3.personClass=@"战士";stl3.easyName=@"gy";
    stl3.level=1;stl3.curEXP=0;stl3.hasThePerson=1;
    stl3.hp=90+45*stl3.level;stl3.damage=25+13*stl3.level;stl3.movement=4;stl3.range=1;
    stl3.power=stl3.hp+stl3.damage*2;
    stl3.skill1=@"";stl3.skill2=@"";stl3.skill3=@"";
    [self insertList:stl3];
    
    sqlTestList *stl4=[[sqlTestList alloc]init];
    stl4.sqlID=4;stl4.personName=@"张飞";stl4.personClass=@"战士";stl4.easyName=@"zf";
    stl4.level=1;stl4.curEXP=0;stl4.hasThePerson=1;
    stl4.hp=110+48*stl4.level;stl4.damage=28+14*stl4.level;stl4.movement=4;stl4.range=1;
    stl4.power=stl4.hp+stl4.damage*2;
    stl4.skill1=@"";stl4.skill2=@"";stl4.skill3=@"";
    [self insertList:stl4];
    
    sqlTestList *stl5=[[sqlTestList alloc]init];
    stl5.sqlID=5;stl5.personName=@"赵云";stl5.personClass=@"战士";stl5.easyName=@"zy";
    stl5.level=1;stl5.curEXP=0;stl5.hasThePerson=1;
    stl5.hp=92+46*stl5.level;stl5.damage=30+13*stl5.level;stl5.movement=4;stl5.range=1;
    stl5.power=stl5.hp+stl5.damage*2;
    stl5.skill1=@"";stl5.skill2=@"";stl5.skill3=@"";
    [self insertList:stl5];
    
    sqlTestList *stl6=[[sqlTestList alloc]init];
    stl6.sqlID=6;stl6.personName=@"马超";stl6.personClass=@"战士";stl6.easyName=@"mc";
    stl6.level=1;stl6.curEXP=0;stl6.hasThePerson=1;
    stl6.hp=100+49*stl6.level;stl6.damage=27+13*stl6.level;stl6.movement=4;stl6.range=1;
    stl6.power=stl6.hp+stl6.damage*2;
    stl6.skill1=@"";stl6.skill2=@"";stl6.skill3=@"";
    [self insertList:stl6];
    
    sqlTestList *stl7=[[sqlTestList alloc]init];
    stl7.sqlID=7;stl7.personName=@"魏延";stl7.personClass=@"战士";stl7.easyName=@"wy";
    stl7.level=1;stl7.curEXP=0;stl7.hasThePerson=1;
    stl7.hp=90+48*stl7.level;stl7.damage=28+12*stl7.level;stl7.movement=3;stl7.range=1;
    stl7.power=stl7.hp+stl7.damage*2;
    stl7.skill1=@"";stl7.skill2=@"";stl7.skill3=@"";
    [self insertList:stl7];
    
    sqlTestList *stl8=[[sqlTestList alloc]init];
    stl8.sqlID=8;stl8.personName=@"黄忠";stl8.personClass=@"弓手";stl8.easyName=@"hz";
    stl8.level=1;stl8.curEXP=0;stl8.hasThePerson=1;
    stl8.hp=120+50*stl8.level;stl8.damage=30+10*stl8.level;stl8.movement=2;stl8.range=3;
    stl8.power=stl8.hp+stl8.damage*2;
    stl8.skill1=@"";stl8.skill2=@"";stl8.skill3=@"";
    [self insertList:stl8];
    
    sqlTestList *stl9=[[sqlTestList alloc]init];
    stl9.sqlID=9;stl9.personName=@"关平";stl9.personClass=@"战士";stl9.easyName=@"gp";
    stl9.level=1;stl9.curEXP=0;stl9.hasThePerson=1;
    stl9.hp=100+44*stl9.level;stl9.damage=30+12*stl9.level;stl9.movement=3;stl9.range=1;
    stl9.power=stl9.hp+stl9.damage*2;
    stl9.skill1=@"";stl9.skill2=@"";stl9.skill3=@"";
    [self insertList:stl9];
    
    sqlTestList *stl10=[[sqlTestList alloc]init];
    stl10.sqlID=10;stl10.personName=@"周仓";stl10.personClass=@"战士";stl10.easyName=@"zc";
    stl10.level=1;stl10.curEXP=0;stl10.hasThePerson=1;
    stl10.hp=100+44*stl10.level;stl10.damage=30+12*stl10.level;stl10.movement=3;stl10.range=1;
    stl10.power=stl10.hp+stl10.damage*2;
    stl10.skill1=@"";stl10.skill2=@"";stl10.skill3=@"";
    [self insertList:stl10];
    
    sqlTestList *stl11=[[sqlTestList alloc]init];
    stl11.sqlID=11;stl11.personName=@"孙尚香";stl11.personClass=@"战士";stl11.easyName=@"ssx";
    stl11.level=5;stl11.curEXP=0;stl11.hasThePerson=1;
    stl11.hp=100+44*stl11.level;stl11.damage=30+12*stl11.level;stl11.movement=3;stl11.range=4;
    stl11.power=stl11.hp+stl11.damage*2;
    stl11.skill1=@"";stl11.skill2=@"";stl11.skill3=@"";
    [self insertList:stl11];
    
 }

-(void)dealloc
{
    [super dealloc];
}

//获取document目录并返回数据库目录
-(NSString *)dataFilePath{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSLog(@"=======%@",documentsDirectory);
    return [documentsDirectory stringByAppendingPathComponent:@"data.db"];//这里很神奇，可以定义成任何类型的文件，也可以不定义成.db文件，任何格局都行，定义成.sb文件都行，达到了很好的数据隐秘性
}

//创建，打开数据库
-(BOOL)openDB {
    //获取数据库路径
    NSString *path = [self dataFilePath];
    //文件经管器
    NSFileManager *fileManager = [NSFileManager defaultManager];
    //断定数据库是否存在
    BOOL find = [fileManager fileExistsAtPath:path];
    //若是数据库存在，则用sqlite3_open直接打开（不要愁闷，若是数据库不存在sqlite3_open会主动创建）
    if (find) {
        NSLog(@"Database file have already existed.");
        //打开数据库，这里的[path UTF8String]是将NSString转换为C字符串，因为SQLite3是采取可移植的C（而不是Objective-C）编写的，它不知道什么是NSString.
        if(sqlite3_open([path UTF8String], &db)!= SQLITE_OK) {
            //若是打开数据库失败则封闭数据库
            sqlite3_close(self.db);
            NSLog(@"Error: open database file.");
            return NO;
        }
        //创建一个新表
        [self createTestList:self.db];
        return YES;
    }
    //若是发明数据库不存在则哄骗sqlite3_open创建数据库（上方已经提到过），与上方雷同，路径要转换为C字符串
    if(sqlite3_open([path UTF8String], &db) == SQLITE_OK) {
        //创建一个新表
        [self createTestList:self.db];
        return YES;
    } else {
        //若是创建并打开数据库失败则封闭数据库
        sqlite3_close(self.db);
        NSLog(@"Error: open database file.");
        return NO;
    }
    return NO;
}

//创建表
-(BOOL)createTestList:(sqlite3*)database {
    char *sql = "create table if not exists testTable(ID INTEGER PRIMARY KEY AUTOINCREMENT, sqlID int,personName text,hasThePerson int,level int,curEXP int,power int,personClass text,hp int,damage int,movement int,range int,skill1 text,skill2 text,skill3 text,easyName text)";
    sqlite3_stmt *statement;
    //sqlite3_prepare_v2 接口把一条SQL语句解析到statement布局里去. 应用该接口接见数据库是当前斗劲好的的一种办法
    NSInteger sqlReturn = sqlite3_prepare_v2(database,sql,-1,&statement,nil);
    //第一个参数跟前面一样，是个sqlite3 * 类型变量，
    //第二个参数是一个 sql 语句。
    //第三个参数我写的是-1，这个参数含义是前面 sql 语句的长度。若是小于0，sqlite会主动策画它的长度（把sql语句当成以\0结尾的字符串）。
    //第四个参数是sqlite3_stmt 的指针的指针。解析今后的sql语句就放在这个布局里。
    //第五个参数是错误信息提示，一般不消，为nil就可以了。
    //若是这个函数履行成功（返回值是 SQLITE_OK 且 statement 不为NULL ），那么下面就可以开端插入二进制数据。
    
    //若是SQL语句解析失足的话法度返回
    if(sqlReturn != SQLITE_OK) {
        NSLog(@"Error: failed to prepare statement:create test table");
        return NO;
    }
    //履行SQL语句
    int success = sqlite3_step(statement);
    //开释sqlite3_stmt
    sqlite3_finalize(statement);
    //履行SQL语句失败
    if(success != SQLITE_DONE) {
        NSLog(@"Error: failed to dehydrate:create table test");
        return NO;
    }
    NSLog(@"Create table ""testTable"" successed.");
    return YES;
}

//插入数据
-(BOOL)insertList:(sqlTestList *)List {
    //先断定数据库是否打开
    if([self openDB]) {
        sqlite3_stmt *statement;
        //这个 sql 语句希罕之处在于 values 里面有个？ 号。在sqlite3_prepare函数里，？号默示一个不决的值，它的值等下才插入。
        static char *sql = "INSERT OR REPLACE INTO testTable(sqlID,personName,hasThePerson,level,curEXP,power,personClass,hp,damage,movement,range,skill1,skill2,skill3,easyName) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        int success2 = sqlite3_prepare_v2(db, sql, -1, &statement, NULL);
        if(success2 != SQLITE_OK) {
            NSLog(@"Error: failed to :testTable");
            sqlite3_close(db);
            return NO;
        }
        //这里的数字1，2，3代表上方的第几个问号，这里将三个值绑定到三个绑定变量
        sqlite3_bind_int(statement, 1, List.sqlID);
        sqlite3_bind_text(statement, 2, [List.personName UTF8String],-1,NULL);
        sqlite3_bind_int(statement, 3, List.hasThePerson);
        sqlite3_bind_int(statement, 4, List.level);
        sqlite3_bind_int(statement, 5, List.curEXP);
        sqlite3_bind_int(statement, 6, List.power);
        sqlite3_bind_text(statement, 7, [List.personClass UTF8String],-1,NULL);
        sqlite3_bind_int(statement, 8, List.hp);
        sqlite3_bind_int(statement, 9, List.damage);
        sqlite3_bind_int(statement, 10, List.movement);
        sqlite3_bind_int(statement, 11, List.range);
        sqlite3_bind_text(statement, 12, [List.skill1 UTF8String],-1,NULL);
        sqlite3_bind_text(statement, 13, [List.skill2 UTF8String],-1,NULL);
        sqlite3_bind_text(statement, 14, [List.skill3 UTF8String],-1,NULL);
        sqlite3_bind_text(statement, 15, [List.easyName UTF8String],-1,NULL);
        NSLog(@"insert success");
        
        //履行插入语句
        success2 = sqlite3_step(statement);
        //开释statement
        sqlite3_finalize(statement);
        //若是插入失败
        if(success2 == SQLITE_ERROR) {
            NSLog(@"Error: failed to  into the database with message.");
            //封闭数据库
            sqlite3_close(db);
            return NO;
        }
        //封闭数据库
        sqlite3_close(db);
        return YES;
    }
    return NO;
}

//获取数据
-(NSMutableArray*)getTestList{
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:10];
    //断定数据库是否打开
    if ([self openDB]) {
        sqlite3_stmt *statement = nil;
        //sql语句
        char *sql = "SELECT sqlID, personName, hasThePerson, level, curEXP,power, personClass, hp, damage, movement, range, skill1, skill2, skill3, easyName FROM testTable";
        if(sqlite3_prepare_v2(db, sql, -1, &statement, NULL) != SQLITE_OK) {
            NSLog(@"Error: failed to prepare statement with message:get testValue.");
            return NO;
        } else {
            //查询成果集中一条一条的遍历所有的记录，这里的数字对应的是列值，重视这里的列值，跟上方sqlite3_bind_text绑定的列值不一样！必然要分隔，不然会crash，只有这一处的列号不合，重视！
            while(sqlite3_step(statement) == SQLITE_ROW) {
                sqlTestList* sqlList = [[sqlTestList alloc] init] ;
                sqlList.sqlID = sqlite3_column_int(statement,1);
                sqlList.personName = [NSString stringWithUTF8String:(char*)sqlite3_column_text(statement, 2)];
                sqlList.hasThePerson = sqlite3_column_int(statement,3);
                sqlList.level = sqlite3_column_int(statement,4);
                sqlList.curEXP = sqlite3_column_int(statement,5);
                sqlList.power = sqlite3_column_int(statement,6);
                sqlList.personClass = [NSString stringWithUTF8String:(char*)sqlite3_column_text(statement, 7)];
                sqlList.hp = sqlite3_column_int(statement,8);
                sqlList.damage = sqlite3_column_int(statement,9);
                sqlList.movement = sqlite3_column_int(statement,10);
                sqlList.range = sqlite3_column_int(statement,11);
                sqlList.skill1 = [NSString stringWithUTF8String:(char*)sqlite3_column_text(statement, 12)];
                sqlList.skill2 = [NSString stringWithUTF8String:(char*)sqlite3_column_text(statement, 13)];
                sqlList.skill3 = [NSString stringWithUTF8String:(char*)sqlite3_column_text(statement, 14)];
                sqlList.easyName = [NSString stringWithUTF8String:(char*)sqlite3_column_text(statement, 15)];
                [array addObject:sqlList];
                [sqlList release];
            }
        }
        sqlite3_finalize(statement);
        sqlite3_close(db);
    }
    return [array retain];//定义了主动开释的NSArray，如许不是个好办法，会造成内存泄漏，建议大师定义局部的数组，再赋给属性变量。
}

//更新数据
-(BOOL)saveList:(sqlTestList *)List {
    if([self openDB]) {
        sqlite3_stmt *statement;//这相当一个容器，放转化OK的sql语句
        //组织SQL语句
        char *sql = "update testTable set personName = ?, hasThePerson = ?, level = ?, curEXP = ?, power = ?, personClass = ?, hp = ?, damage = ?, movement = ?, range = ?, skill1 = ?, skill2 = ?, skill3 = ?, easyName = ? WHERE sqlID = ?";
        //将SQL语句放入sqlite3_stmt中
        int success = sqlite3_prepare_v2(db, sql, -1, &statement, NULL);
        if (success != SQLITE_OK){
            NSLog(@"Error: failed to :testTable");
            sqlite3_close(db);
            return NO;
        }
        //这里的数字1，2，3代表第几个问号。这里只有1个问号，这是一个相对斗劲简单的数据库操纵，真正的项目中会远远比这个错杂
        //绑定text类型的数据库数据
        sqlite3_bind_text(statement, 1, [List.personName UTF8String],-1,NULL);
        sqlite3_bind_int(statement, 2, List.hasThePerson);
        sqlite3_bind_int(statement, 3, List.level);
        sqlite3_bind_int(statement, 4, List.curEXP);
        sqlite3_bind_int(statement, 5, List.power);
        sqlite3_bind_text(statement, 6, [List.personClass UTF8String],-1,NULL);
        sqlite3_bind_int(statement, 7, List.hp);
        sqlite3_bind_int(statement, 8, List.damage);
        sqlite3_bind_int(statement, 9, List.movement);
        sqlite3_bind_int(statement, 10, List.range);
        sqlite3_bind_text(statement, 11, [List.skill1 UTF8String],-1,NULL);
        sqlite3_bind_text(statement, 12, [List.skill2 UTF8String],-1,NULL);
        sqlite3_bind_text(statement, 13, [List.skill3 UTF8String],-1,NULL);
        sqlite3_bind_text(statement, 14, [List.easyName UTF8String],-1,NULL);
        sqlite3_bind_int(statement, 15, List.sqlID);
        
        //履行SQL语句。这里是更新数据库
        success = sqlite3_step(statement);
        //开释statement
        sqlite3_finalize(statement);
        //若是履行失败
        if(success == SQLITE_ERROR) {
            NSLog(@"Error: failed to  the database with message.");
            //封闭数据库
            sqlite3_close(db);
            return NO;
        }
        //履行成功后依然要封闭数据库
        sqlite3_close(db);
        return YES;
    }
    return NO;
}
//删除数据
-(BOOL)deleteList:(sqlTestList *)deletList{
    if([self openDB]){
        sqlite3_stmt *statement;
        //组织SQL语句
        static char *sql = "delete from testTable  where sqlID = ?";
        //将SQL语句放入sqlite3_stmt中
        int success = sqlite3_prepare_v2(db, sql, -1, &statement, NULL);
        if (success != SQLITE_OK){
            NSLog(@"Error: failed to :testTable");
            sqlite3_close(db);
            return NO;
        }
        //这里的数字1，2，3代表第几个问号。这里只有1个问号，这是一个相对斗劲简单的数据库操纵，真正的项目中会远远比这个错杂
        sqlite3_bind_int(statement, 1, deletList.sqlID);
        //履行SQL语句。这里是更新数据库
        success = sqlite3_step(statement);
        //开释statement
        sqlite3_finalize(statement);
        //若是履行失败
        if(success == SQLITE_ERROR){
            NSLog(@"Error: failed to  the database with message.");
            //封闭数据库
            sqlite3_close(db);
            return NO;
        }
        //履行成功后依然要封闭数据库
        sqlite3_close(db);
        return YES;
    }
    return NO;
}

//查询数据
-(sqlTestList*)searchTestList:(int)searchID{
    sqlTestList* sqlList = [[sqlTestList alloc] init] ;
    //断定数据库是否打开
    if([self openDB]) {
        sqlite3_stmt *statement = nil;
        //sql语句
        char *sql = "SELECT * FROM testTable where sqlID = ?";
        //char *sql = "SELECT * FROM testTable WHERE testName like ？";//这里用like庖代=可以履行模糊查找，本来是"SELECT * FROM testTable WHERE testName = ？"
        if (sqlite3_prepare_v2(db, sql, -1, &statement, NULL) != SQLITE_OK){
            NSLog(@"Error: failed to prepare statement with message:search testValue.");
            return NO;
        } else {
            sqlite3_bind_int(statement, 1, searchID);
            //查询成果集中一条一条的遍历所有的记录，这里的数字对应的是列值。
            while(sqlite3_step(statement) == SQLITE_ROW) {                
                sqlList.sqlID = sqlite3_column_int(statement,1);
                sqlList.personName = [NSString stringWithUTF8String:(char*)sqlite3_column_text(statement, 2)];
                sqlList.hasThePerson = sqlite3_column_int(statement,3);
                sqlList.level = sqlite3_column_int(statement,4);
                sqlList.curEXP = sqlite3_column_int(statement,5);
                sqlList.power = sqlite3_column_int(statement,6);
                sqlList.personClass = [NSString stringWithUTF8String:(char*)sqlite3_column_text(statement, 7)];
                sqlList.hp = sqlite3_column_int(statement,8);
                sqlList.damage = sqlite3_column_int(statement,9);
                sqlList.movement = sqlite3_column_int(statement,10);
                sqlList.range = sqlite3_column_int(statement,11);
                sqlList.skill1 = [NSString stringWithUTF8String:(char*)sqlite3_column_text(statement, 12)];
                sqlList.skill2 = [NSString stringWithUTF8String:(char*)sqlite3_column_text(statement, 13)];
                sqlList.skill3 = [NSString stringWithUTF8String:(char*)sqlite3_column_text(statement, 14)];
                sqlList.easyName = [NSString stringWithUTF8String:(char*)sqlite3_column_text(statement, 15)];
            }
        }
        sqlite3_finalize(statement);
        sqlite3_close(db);
    }
    return sqlList;
}
@end

@implementation sqlTestList
@synthesize sqlID;
@synthesize personName,hasThePerson,level,curEXP,power,personClass,hp,damage,movement,range,skill1,skill2,skill3,easyName;
-(id)init
{
    sqlID = 0;
    personName=@"";
    hasThePerson=0;
    level=0;
    curEXP=0;
    power=0;
    hp=0;
    damage=0;
    movement=0;
    range=0;
    skill1=@"";
    skill2=@"";
    skill3=@"";
    easyName=@"";
    return self;
};

-(void)dealloc
{
    [super dealloc];
}
@end