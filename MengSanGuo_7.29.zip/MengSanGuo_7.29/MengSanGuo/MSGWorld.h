//
//  MSGWorld.h
//  Team
//
//  Created by naxx on 13-7-22.
//
//

#ifndef __Team__MSGWorld__
#define __Team__MSGWorld__

#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"
#include "Role.h"
#include "makeNewUser.h"
#include "BattleMapScene.h"
#include "MilitaryCommandersPanel.h"
USING_NS_CC;
USING_NS_CC_EXT;
class MSGWorld:public CCLayer ,public CCScrollViewDelegate
{
public:
    
    MSGWorld();
    ~MSGWorld();
    
    static CCScene *scene();
    
    virtual bool init();
    CREATE_FUNC(MSGWorld);
    
    virtual void scrollViewDidScroll(CCScrollView* view);
    virtual void scrollViewDidZoom(CCScrollView* view);
    
    void Zhuchengshengji();

    void shijianlan();
    void wujianglan();
    void ZhengZhanLan();
 

};
#endif /* defined(__Team__MSGWorld__) */
