//
//  BattleMapHud.cpp
//  mySanGuo
//
//  Created by macbook on 13-7-22.
//
//

#include "BattleMapHud.h"

bool BattleMapHud::init()
{
    if ( !CCLayer::init() )
    {
        return false;
    }
    
    this->scheduleOnce(schedule_selector(BattleMapHud::showStoryLine1), 2);
    this->scheduleOnce(schedule_selector(BattleMapHud::showStoryLine2), 4);
    this->scheduleOnce(schedule_selector(BattleMapHud::showStoryLine3), 6);
    this->scheduleOnce(schedule_selector(BattleMapHud::showStoryLine4), 8);
    this->scheduleOnce(schedule_selector(BattleMapHud::hideStoryLine), 10);
    
    return true;
}
void BattleMapHud::showStoryLine1()
{
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==1) {
        CCUserDefault::sharedUserDefault()->setBoolForKey("storyMode", true);
        CCLabelTTF *ccl1=CCLabelTTF::create("刘关张三人路过此地", "Arial", 18, CCSize(20,200), kCCTextAlignmentCenter);
        ccl1->setPosition(ccp(40,160));
        this->addChild(ccl1);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==2) {
        CCUserDefault::sharedUserDefault()->setBoolForKey("storyMode", true);
        CCLabelTTF *ccl1=CCLabelTTF::create("此时刘备依附于公孙瓒", "Arial", 18, CCSize(20,240), kCCTextAlignmentCenter);
        ccl1->setPosition(ccp(40,160));
        this->addChild(ccl1);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==3) {
        CCUserDefault::sharedUserDefault()->setBoolForKey("storyMode", true);
        CCLabelTTF *ccl1=CCLabelTTF::create("博望相持用火攻", "Arial", 18, CCSize(20,200), kCCTextAlignmentCenter);
        ccl1->setPosition(ccp(40,160));
        this->addChild(ccl1);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==4) {
        CCUserDefault::sharedUserDefault()->setBoolForKey("storyMode", true);
        CCLabelTTF *ccl1=CCLabelTTF::create("本为刘表部下中郎将", "Arial", 18, CCSize(20,200), kCCTextAlignmentCenter);
        ccl1->setPosition(ccp(40,160));
        this->addChild(ccl1);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==5) {
        CCUserDefault::sharedUserDefault()->setBoolForKey("storyMode", true);
        CCLabelTTF *ccl1=CCLabelTTF::create("五虎上将齐上阵", "Arial", 18, CCSize(20,200), kCCTextAlignmentCenter);
        ccl1->setPosition(ccp(40,160));
        this->addChild(ccl1);
    }
    
}
void BattleMapHud::showStoryLine2()
{
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==1) {
        CCLabelTTF *ccl2=CCLabelTTF::create("遇上此地的一伙土匪", "Arial", 18, CCSize(20,200), kCCTextAlignmentCenter);
        ccl2->setPosition(ccp(80,160));
        this->addChild(ccl2);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==2) {
        CCLabelTTF *ccl2=CCLabelTTF::create("公孙瓒准备与袁绍交战", "Arial", 18, CCSize(20,240), kCCTextAlignmentCenter);
        ccl2->setPosition(ccp(80,160));
        this->addChild(ccl2);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==3) {
        CCLabelTTF *ccl2=CCLabelTTF::create("指挥如意笑谈中", "Arial", 18, CCSize(20,200), kCCTextAlignmentCenter);
        ccl2->setPosition(ccp(80,160));
        this->addChild(ccl2);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==4) {
        CCLabelTTF *ccl2=CCLabelTTF::create("后归刘备并助其攻益州", "Arial", 18, CCSize(20,240), kCCTextAlignmentCenter);
        ccl2->setPosition(ccp(80,160));
        this->addChild(ccl2);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==5) {
        CCLabelTTF *ccl2=CCLabelTTF::create("誓为刘备夺孙夫人", "Arial", 18, CCSize(20,200), kCCTextAlignmentCenter);
        ccl2->setPosition(ccp(80,160));
        this->addChild(ccl2);
    }
    
}
void BattleMapHud::showStoryLine3()
{
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==1) {
        CCLabelTTF *ccl3=CCLabelTTF::create("其中带头的名叫周仓", "Arial", 18, CCSize(20,200), kCCTextAlignmentCenter);
        ccl3->setPosition(ccp(120,160));
        this->addChild(ccl3);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==2) {
        CCLabelTTF *ccl3=CCLabelTTF::create("派刘备助田楷抵抗袁绍", "Arial", 18, CCSize(20,240), kCCTextAlignmentCenter);
        ccl3->setPosition(ccp(120,160));
        this->addChild(ccl3);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==3) {
        CCLabelTTF *ccl3=CCLabelTTF::create("直须惊破曹公胆", "Arial", 18, CCSize(20,200), kCCTextAlignmentCenter);
        ccl3->setPosition(ccp(120,160));
        this->addChild(ccl3);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==4) {
        CCLabelTTF *ccl3=CCLabelTTF::create("此人箭术天下第一", "Arial", 18, CCSize(20,200), kCCTextAlignmentCenter);
        ccl3->setPosition(ccp(120,160));
        this->addChild(ccl3);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==5) {
        CCLabelTTF *ccl3=CCLabelTTF::create("有情人终成眷属", "Arial", 18, CCSize(20,200), kCCTextAlignmentCenter);
        ccl3->setPosition(ccp(120,160));
        this->addChild(ccl3);
    }
    
}
void BattleMapHud::showStoryLine4()
{
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==1) {
        CCLabelTTF *ccl4=CCLabelTTF::create("乃是响当当的一号人物", "Arial", 18, CCSize(20,200), kCCTextAlignmentCenter);
        ccl4->setPosition(ccp(160,160));
        this->addChild(ccl4);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==2) {
        CCLabelTTF *ccl4=CCLabelTTF::create("并派赵云为刘备的随从", "Arial", 18, CCSize(20,240), kCCTextAlignmentCenter);
        ccl4->setPosition(ccp(160,160));
        this->addChild(ccl4);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==3) {
        CCLabelTTF *ccl4=CCLabelTTF::create("初出茅庐第一功", "Arial", 18, CCSize(20,200), kCCTextAlignmentCenter);
        ccl4->setPosition(ccp(160,160));
        this->addChild(ccl4);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==4) {
        CCLabelTTF *ccl4=CCLabelTTF::create("唯有五虎上将黄忠也", "Arial", 18, CCSize(20,220), kCCTextAlignmentCenter);
        ccl4->setPosition(ccp(160,160));
        this->addChild(ccl4);
    }
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==5) {
        CCLabelTTF *ccl4=CCLabelTTF::create("欲知后事且听下回分析", "Arial", 18, CCSize(20,260), kCCTextAlignmentCenter);
        ccl4->setPosition(ccp(160,160));
        this->addChild(ccl4);
    }
    
}
void BattleMapHud::hideStoryLine()
{
    this->removeAllChildrenWithCleanup(true);
    CCUserDefault::sharedUserDefault()->setBoolForKey("storyMode", false);
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==1) this->showBattle1Detail();
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==2) this->showBattle2Detail();
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==3) this->showBattle3Detail();
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==4) this->showBattle4Detail();
    if (CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule")==5) this->showBattle5Detail();
    
}

void BattleMapHud::showBattle1Detail()
{
    CCUserDefault::sharedUserDefault()->setBoolForKey("moveEnable", false);
    
    battleDetailView=CCSprite::create("battleDetailView.png");
    battleDetailView->setPosition(ccp(580, 160));
    battleDetailView->setScaleX(0.65);
    battleDetailView->setVisible(true);
    this->addChild(battleDetailView);

    CCLabelTTF *title=CCLabelTTF::create("讨伐土匪周仓", "Arial", 28);
    title->setColor(ccc3(255, 0, 0));
    title->setPosition(ccp(160, 240));
    battleDetailView->addChild(title,1);
    CCLabelTTF *detail1=CCLabelTTF::create("敌方武将   :   周仓", "Arial", 18);
    detail1->setColor(ccc3(255, 100, 0));
    detail1->setPosition(ccp(160, 180));
    battleDetailView->addChild(detail1,1);
    CCLabelTTF *detail2=CCLabelTTF::create("敌方小兵   :   战士*4", "Arial", 18);
    detail2->setColor(ccc3(255, 100, 0));
    detail2->setPosition(ccp(160, 150));
    battleDetailView->addChild(detail2,1);
       
    battleDetailView->runAction(CCMoveTo::create(1, ccp(380, 160)));

    CCMenuItemSprite *yes_btn=CCMenuItemSprite::create(CCSprite::create("yes.png"), CCSprite::create("yes_sec.png"), this, menu_selector(BattleMapHud::chooseYes));
    yes_btn->setPosition(ccp(100, 60));
    yes_btn->setScaleY(0.65);
    CCMenuItemSprite *no_btn=CCMenuItemSprite::create(CCSprite::create("no.png"), CCSprite::create("no_sec.png"), this, menu_selector(BattleMapHud::chooseNo));
    no_btn->setPosition(ccp(220, 60));
    no_btn->setScaleY(0.65);
    
    CCMenu *yesOrNo=CCMenu::create(yes_btn,no_btn,NULL);
    yesOrNo->setPosition(ccp(0, 0));
    battleDetailView->addChild(yesOrNo,1);

}
void BattleMapHud::showBattle2Detail()
{
    CCUserDefault::sharedUserDefault()->setBoolForKey("moveEnable", false);
    
    battleDetailView=CCSprite::create("battleDetailView.png");
    battleDetailView->setPosition(ccp(580, 160));
    battleDetailView->setScaleX(0.65);
    battleDetailView->setVisible(true);
    this->addChild(battleDetailView);
    
    CCLabelTTF *title=CCLabelTTF::create("赵云初露锋芒", "Arial", 28);
    title->setColor(ccc3(255, 0, 0));
    title->setPosition(ccp(160, 240));
    battleDetailView->addChild(title,1);
    CCLabelTTF *detail1=CCLabelTTF::create("敌方武将   :   无", "Arial", 18);
    detail1->setColor(ccc3(255, 100, 0));
    detail1->setPosition(ccp(160, 180));
    battleDetailView->addChild(detail1,1);
    CCLabelTTF *detail2=CCLabelTTF::create("敌方小兵  :  战士*2", "Arial", 18);
    detail2->setColor(ccc3(255, 100, 0));
    detail2->setPosition(ccp(160, 150));
    battleDetailView->addChild(detail2,1);
    CCLabelTTF *detail3=CCLabelTTF::create("                 弓手*2", "Arial", 18);
    detail3->setColor(ccc3(255, 100, 0));
    detail3->setPosition(ccp(160, 130));
    battleDetailView->addChild(detail3,1);
    CCLabelTTF *detail4=CCLabelTTF::create("                 谋士*1", "Arial", 18);
    detail4->setColor(ccc3(255, 100, 0));
    detail4->setPosition(ccp(160, 110));
    battleDetailView->addChild(detail4,1);
    
    battleDetailView->runAction(CCMoveTo::create(1, ccp(380, 160)));
    
    CCMenuItemSprite *yes_btn=CCMenuItemSprite::create(CCSprite::create("yes.png"), CCSprite::create("yes_sec.png"), this, menu_selector(BattleMapHud::chooseYes));
    yes_btn->setPosition(ccp(100, 60));
    yes_btn->setScaleY(0.65);
    CCMenuItemSprite *no_btn=CCMenuItemSprite::create(CCSprite::create("no.png"), CCSprite::create("no_sec.png"), this, menu_selector(BattleMapHud::chooseNo));
    no_btn->setPosition(ccp(220, 60));
    no_btn->setScaleY(0.65);
    CCMenu *yesOrNo=CCMenu::create(yes_btn,no_btn,NULL);
    yesOrNo->setPosition(ccp(0, 0));
    battleDetailView->addChild(yesOrNo,1);
}
void BattleMapHud::showBattle3Detail()
{
    CCUserDefault::sharedUserDefault()->setBoolForKey("moveEnable", false);
    
    battleDetailView=CCSprite::create("battleDetailView.png");
    battleDetailView->setPosition(ccp(580, 160));
    battleDetailView->setScaleX(0.65);
    battleDetailView->setVisible(true);
    this->addChild(battleDetailView);
    
    CCLabelTTF *title=CCLabelTTF::create("火烧博望坡", "Arial", 28);
    title->setColor(ccc3(255, 0, 0));
    title->setPosition(ccp(160, 240));
    battleDetailView->addChild(title,1);
    CCLabelTTF *detail1=CCLabelTTF::create("敌方武将   :   夏侯惇", "Arial", 18);
    detail1->setColor(ccc3(255, 100, 0));
    detail1->setPosition(ccp(160, 180));
    battleDetailView->addChild(detail1,1);
    CCLabelTTF *detail2=CCLabelTTF::create("敌方小兵  :  战士*2", "Arial", 18);
    detail2->setColor(ccc3(255, 100, 0));
    detail2->setPosition(ccp(160, 150));
    battleDetailView->addChild(detail2,1);
    CCLabelTTF *detail3=CCLabelTTF::create("                 弓手*2", "Arial", 18);
    detail3->setColor(ccc3(255, 100, 0));
    detail3->setPosition(ccp(160, 130));
    battleDetailView->addChild(detail3,1);
    
    battleDetailView->runAction(CCMoveTo::create(1, ccp(380, 160)));
    
    CCMenuItemSprite *yes_btn=CCMenuItemSprite::create(CCSprite::create("yes.png"), CCSprite::create("yes_sec.png"), this, menu_selector(BattleMapHud::chooseYes));
    yes_btn->setPosition(ccp(100, 60));
    yes_btn->setScaleY(0.65);
    CCMenuItemSprite *no_btn=CCMenuItemSprite::create(CCSprite::create("no.png"), CCSprite::create("no_sec.png"), this, menu_selector(BattleMapHud::chooseNo));
    no_btn->setPosition(ccp(220, 60));
    no_btn->setScaleY(0.65);
    CCMenu *yesOrNo=CCMenu::create(yes_btn,no_btn,NULL);
    yesOrNo->setPosition(ccp(0, 0));
    battleDetailView->addChild(yesOrNo,1);
}
void BattleMapHud::showBattle4Detail()
{
    CCUserDefault::sharedUserDefault()->setBoolForKey("moveEnable", false);
    
    battleDetailView=CCSprite::create("battleDetailView.png");
    battleDetailView->setPosition(ccp(580, 160));
    battleDetailView->setScaleX(0.65);
    battleDetailView->setVisible(true);
    this->addChild(battleDetailView);
    
    CCLabelTTF *title=CCLabelTTF::create("百步穿杨老黄忠", "Arial", 28);
    title->setColor(ccc3(255, 0, 0));
    title->setPosition(ccp(160, 240));
    battleDetailView->addChild(title,1);
    CCLabelTTF *detail1=CCLabelTTF::create("敌方武将   :   无", "Arial", 18);
    detail1->setColor(ccc3(255, 100, 0));
    detail1->setPosition(ccp(160, 180));
    battleDetailView->addChild(detail1,1);
    CCLabelTTF *detail2=CCLabelTTF::create("敌方小兵  :  战士*3", "Arial", 18);
    detail2->setColor(ccc3(255, 100, 0));
    detail2->setPosition(ccp(160, 150));
    battleDetailView->addChild(detail2,1);
    CCLabelTTF *detail3=CCLabelTTF::create("                 谋士*2", "Arial", 18);
    detail3->setColor(ccc3(255, 100, 0));
    detail3->setPosition(ccp(160, 130));
    battleDetailView->addChild(detail3,1);
    
    battleDetailView->runAction(CCMoveTo::create(1, ccp(380, 160)));
    
    CCMenuItemSprite *yes_btn=CCMenuItemSprite::create(CCSprite::create("yes.png"), CCSprite::create("yes_sec.png"), this, menu_selector(BattleMapHud::chooseYes));
    yes_btn->setPosition(ccp(100, 60));
    yes_btn->setScaleY(0.65);
    CCMenuItemSprite *no_btn=CCMenuItemSprite::create(CCSprite::create("no.png"), CCSprite::create("no_sec.png"), this, menu_selector(BattleMapHud::chooseNo));
    no_btn->setPosition(ccp(220, 60));
    no_btn->setScaleY(0.65);
    CCMenu *yesOrNo=CCMenu::create(yes_btn,no_btn,NULL);
    yesOrNo->setPosition(ccp(0, 0));
    battleDetailView->addChild(yesOrNo,1);
}
void BattleMapHud::showBattle5Detail()
{
    CCUserDefault::sharedUserDefault()->setBoolForKey("moveEnable", false);
    
    battleDetailView=CCSprite::create("battleDetailView.png");
    battleDetailView->setPosition(ccp(580, 160));
    battleDetailView->setScaleX(0.65);
    battleDetailView->setVisible(true);
    this->addChild(battleDetailView);
    
    CCLabelTTF *title=CCLabelTTF::create("有情人终成眷属", "Arial", 28);
    title->setColor(ccc3(255, 0, 0));
    title->setPosition(ccp(160, 240));
    battleDetailView->addChild(title,1);
    CCLabelTTF *detail1=CCLabelTTF::create("敌方武将   :   未知", "Arial", 18);
    detail1->setColor(ccc3(255, 100, 0));
    detail1->setPosition(ccp(160, 180));
    battleDetailView->addChild(detail1,1);
    CCLabelTTF *detail2=CCLabelTTF::create("敌方小兵  :  未知", "Arial", 18);
    detail2->setColor(ccc3(255, 100, 0));
    detail2->setPosition(ccp(160, 150));
    battleDetailView->addChild(detail2,1);
    
    battleDetailView->runAction(CCMoveTo::create(1, ccp(380, 160)));
    
    CCMenuItemSprite *yes_btn=CCMenuItemSprite::create(CCSprite::create("yes.png"), CCSprite::create("yes_sec.png"), this, menu_selector(BattleMapHud::chooseYes));
    yes_btn->setPosition(ccp(100, 60));
    yes_btn->setScaleY(0.65);
    CCMenuItemSprite *no_btn=CCMenuItemSprite::create(CCSprite::create("no.png"), CCSprite::create("no_sec.png"), this, menu_selector(BattleMapHud::chooseNo));
    no_btn->setPosition(ccp(220, 60));
    no_btn->setScaleY(0.65);
    CCMenu *yesOrNo=CCMenu::create(yes_btn,no_btn,NULL);
    yesOrNo->setPosition(ccp(0, 0));
    battleDetailView->addChild(yesOrNo,1);
}
void BattleMapHud::chooseYes()
{
    CCDirector::sharedDirector()->replaceScene(BattleScene::create());
}
void BattleMapHud::chooseNo()
{
    CCUserDefault::sharedUserDefault()->setBoolForKey("moveEnable", true);
    battleDetailView->setVisible(false);
    battleDetailView->removeAllChildrenWithCleanup(true);
    battleDetailView=NULL;
}