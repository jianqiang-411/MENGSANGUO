//
//  BattleMap.h
//  mySanGuo
//
//  Created by macbook on 13-7-22.
//
//

#ifndef __mySanGuo__BattleMap__
#define __mySanGuo__BattleMap__

#include <iostream>

#include "cocos2d.h"
using namespace cocos2d;

class BattleMapHud;
class BattleMap:public CCLayer
{
public:
    BattleMapHud *myHud;
    int choose;
    CCUserDefault *myData;
    CCSprite *battle1;
    CCSprite *battle2;
    CCSprite *battle3;
    CCSprite *battle4;
    CCSprite *battle5;
    CCMenuItemSprite *battle1_btn;
    CCMenuItemSprite *battle2_btn;
    CCMenuItemSprite *battle3_btn;
    CCMenuItemSprite *battle4_btn;
    CCMenuItemSprite *battle5_btn;
    CCSprite *yun1;
    CCSprite *yun2;
    CCSprite *yun3;
    CCSprite *yun4;
    CCSprite *yun5;
    
    virtual bool init();

    void battle2Display();
    void battle3Display();
    void battle4Display();
    void battle5Display();
    void goToBattle1();
    void goToBattle2();
    void goToBattle3();
    void goToBattle4();
    void goToBattle5();
    
    CREATE_FUNC(BattleMap);
};

#endif /* defined(__mySanGuo__BattleMap__) */
