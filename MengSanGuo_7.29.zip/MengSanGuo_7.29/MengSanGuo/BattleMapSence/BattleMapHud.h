//
//  BattleMapHud.h
//  mySanGuo
//
//  Created by macbook on 13-7-22.
//
//

#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
#include "BattleScene.h"
using namespace cocos2d;

class BattleMap;
class BattleMapHud:public CCLayer
{
public:
    BattleMap *myLayer;
    CCUserDefault *myData;
    CCSprite *battleDetailView;
    virtual bool init();
    
    CREATE_FUNC(BattleMapHud);
    
    void showBattle1Detail();
    void showBattle2Detail();
    void showBattle3Detail();
    void showBattle4Detail();
    void showBattle5Detail();
    void chooseYes();
    void chooseNo();
    
    void showStoryLine1();
    void showStoryLine2();
    void showStoryLine3();
    void showStoryLine4();
    void hideStoryLine();
};
#endif
