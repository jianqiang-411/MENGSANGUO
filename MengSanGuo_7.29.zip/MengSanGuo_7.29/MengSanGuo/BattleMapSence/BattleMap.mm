//
//  BattleMap.cpp
//  mySanGuo
//
//  Created by macbook on 13-7-22.
//
//

#include "BattleMap.h"
#include "BattleMapHud.h"

bool BattleMap::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
        return false;
    }
    CCUserDefault::sharedUserDefault()->setIntegerForKey("storySchedule", 5);
    CCUserDefault::sharedUserDefault()->flush();
    
    choose=CCUserDefault::sharedUserDefault()->getIntegerForKey("storySchedule");
    
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("xiaoren.plist");
    CCSpriteBatchNode *spriteSheet=CCSpriteBatchNode::create("xiaoren.png");
    this->addChild(spriteSheet);
    
    CCArray *personIMGFrames=CCArray::createWithCapacity(25);
    for (int i=1; i<=24; ++i) {
        personIMGFrames->addObject(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(CCString::createWithFormat("xiaoren-%d.png",i)->getCString()));
    }
    CCAnimation *personIMGAnim=CCAnimation::createWithSpriteFrames(personIMGFrames,0.2f);
    
    CCArray *yunIMGFrames=CCArray::createWithCapacity(5);
    for (int i=1; i<=4; ++i) {
        yunIMGFrames->addObject(CCSpriteFrame::create(CCString::createWithFormat("yun-%d.png",i)->getCString(), CCRectMake(0, 0, 48, 48)));
    }
    CCAnimation *yunIMGAnim=CCAnimation::createWithSpriteFrames(yunIMGFrames, 0.2f);
    
    CCSprite *battleMap=CCSprite::create("bg.jpg");
    battleMap->setPosition(ccp(100,200));
    this->addChild(battleMap,-1);
    
    battle1=CCSprite::createWithSpriteFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("xiaoren-1.png"));
    battle1->setPosition(ccp(330,20));
    battle1->setScale(0.8);
    this->addChild(battle1,-1);
    battle1->runAction(CCRepeatForever::create(CCAnimate::create(personIMGAnim)));
    yun1=CCSprite::create();yun1->setPosition(ccp(330,40));yun1->setVisible(false);this->addChild(yun1);
    yun1->runAction(CCRepeatForever::create(CCAnimate::create(yunIMGAnim)));
    
    CCSprite *arrow1=CCSprite::create("arrow.png");
    arrow1->setPosition(ccp(290,80));
    arrow1->setRotation(50.0);
    arrow1->setVisible(false);
    this->addChild(arrow1,-1);
    
    battle2=CCSprite::createWithSpriteFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("xiaoren-1.png"));
    battle2->setPosition(ccp(240,140));
    battle2->setScale(0.8);
    battle2->setVisible(false);
    this->addChild(battle2,-1);
    battle2->runAction(CCRepeatForever::create(CCAnimate::create(personIMGAnim)));
    yun2=CCSprite::create();yun2->setPosition(ccp(240,160));yun2->setVisible(false);this->addChild(yun2);
    yun2->runAction(CCRepeatForever::create(CCAnimate::create(yunIMGAnim)));
    
    CCSprite *arrow2=CCSprite::create("arrow.png");
    arrow2->setPosition(ccp(180,165));
    arrow2->setRotation(35.0);
    arrow2->setVisible(false);
    this->addChild(arrow2,-1);
    
    battle3=CCSprite::createWithSpriteFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("xiaoren-1.png"));
    battle3->setPosition(ccp(80,240));
    battle3->setScale(0.8);
    battle3->setVisible(false);
    this->addChild(battle3,-1);
    battle3->runAction(CCRepeatForever::create(CCAnimate::create(personIMGAnim)));
    yun3=CCSprite::create();yun3->setPosition(ccp(80,260));yun3->setVisible(false);this->addChild(yun3);
    yun3->runAction(CCRepeatForever::create(CCAnimate::create(yunIMGAnim)));

    CCSprite *arrow3=CCSprite::create("arrow.png");
    arrow3->setPosition(ccp(20,262));
    arrow3->setRotation(35.0);
    arrow3->setVisible(false);
    this->addChild(arrow3,-1);

    battle4=CCSprite::createWithSpriteFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("xiaoren-1.png"));
    battle4->setPosition(ccp(-40,300));
    battle4->setScale(0.8);
    battle4->setVisible(false);
    this->addChild(battle4,-1);
    battle4->runAction(CCRepeatForever::create(CCAnimate::create(personIMGAnim)));
    yun4=CCSprite::create();yun4->setPosition(ccp(-40,320));yun4->setVisible(false);this->addChild(yun4);
    yun4->runAction(CCRepeatForever::create(CCAnimate::create(yunIMGAnim)));

    CCSprite *arrow4=CCSprite::create("arrow.png");
    arrow4->setPosition(ccp(-132,350));
    arrow4->setRotation(35.0);
    arrow4->setVisible(false);
    this->addChild(arrow4,-1);

    battle5=CCSprite::createWithSpriteFrame(CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("xiaoren-1.png"));
    battle5->setPosition(ccp(-190,390));
    battle5->setScale(0.8);
    battle5->setVisible(false);
    this->addChild(battle5,-1);
    battle5->runAction(CCRepeatForever::create(CCAnimate::create(personIMGAnim)));
    yun5=CCSprite::create();yun5->setPosition(ccp(-190,410));yun5->setVisible(false);this->addChild(yun5);
    yun5->runAction(CCRepeatForever::create(CCAnimate::create(yunIMGAnim)));
    
    battle1_btn=CCMenuItemSprite::create(CCSprite::createWithSpriteFrameName("xiaoren-1.png"), CCSprite::createWithSpriteFrameName("xiaoren-1.png"), this, menu_selector(BattleMap::goToBattle1));
    battle1_btn->setPosition(battle1->getPosition());
    battle1_btn->setScale(battle1->getScale());
    battle1_btn->setVisible(battle1->isVisible());
    battle2_btn=CCMenuItemSprite::create(CCSprite::createWithSpriteFrameName("xiaoren-1.png"), CCSprite::createWithSpriteFrameName("xiaoren-1.png"), this, menu_selector(BattleMap::goToBattle2));
    battle2_btn->setPosition(battle2->getPosition());
    battle2_btn->setScale(battle2->getScale());
    battle2_btn->setVisible(battle2->isVisible());
    battle3_btn=CCMenuItemSprite::create(CCSprite::createWithSpriteFrameName("xiaoren-1.png"), CCSprite::createWithSpriteFrameName("xiaoren-1.png"), this, menu_selector(BattleMap::goToBattle3));
    battle3_btn->setPosition(battle3->getPosition());
    battle3_btn->setScale(battle3->getScale());
    battle3_btn->setVisible(battle3->isVisible());
    battle4_btn=CCMenuItemSprite::create(CCSprite::createWithSpriteFrameName("xiaoren-1.png"), CCSprite::createWithSpriteFrameName("xiaoren-1.png"), this, menu_selector(BattleMap::goToBattle4));
    battle4_btn->setPosition(battle4->getPosition());
    battle4_btn->setScale(battle4->getScale());
    battle4_btn->setVisible(battle4->isVisible());
    battle5_btn=CCMenuItemSprite::create(CCSprite::createWithSpriteFrameName("xiaoren-1.png"), CCSprite::createWithSpriteFrameName("xiaoren-1.png"), this, menu_selector(BattleMap::goToBattle5));
    battle5_btn->setPosition(battle5->getPosition());
    battle5_btn->setScale(battle5->getScale());
    battle5_btn->setVisible(battle5->isVisible());
    
    CCMenu *menu=CCMenu::create(battle1_btn,battle2_btn,battle3_btn,battle4_btn,battle5_btn,NULL);
    menu->setPosition(ccp(0,0));
    this->addChild(menu,-2);
    
    if(choose==1){
        this->setPosition(ccp(240-battle1->getPositionX(),160-battle1->getPositionY()-50));
    }
    if (choose==2) {
        this->setPosition(ccp(240-battle1->getPositionX(),160-battle1->getPositionY()-50));
        this->runAction(CCSequence::create(CCMoveTo::create(8, ccp(240-battle2->getPositionX(),160-battle2->getPositionY())),
                                           CCDelayTime::create(2),CCCallFunc::create(this, callfunc_selector(BattleMap::battle2Display)),NULL));
        arrow1->runAction(CCRepeatForever::create(CCBlink::create(2, 1)));
        yun1->setVisible(true);
    }
    if(choose==3){
        this->setPosition(ccp(240-battle2->getPositionX(),160-battle2->getPositionY()));
        this->runAction(CCSequence::create(CCMoveTo::create(8, ccp(240-battle3->getPositionX(),160-battle3->getPositionY())),
                                           CCDelayTime::create(2),CCCallFunc::create(this, callfunc_selector(BattleMap::battle3Display)),NULL));
        arrow1->setVisible(true);
        battle2->setVisible(true);battle2_btn->setVisible(true);
        arrow2->runAction(CCRepeatForever::create(CCBlink::create(2, 1)));
        yun1->setVisible(true);yun2->setVisible(true);
    }
    if(choose==4){
        this->setPosition(ccp(240-battle3->getPositionX(),160-battle3->getPositionY()));
        this->runAction(CCSequence::create(CCMoveTo::create(8, ccp(240-battle4->getPositionX(),160-battle4->getPositionY())),
                                           CCDelayTime::create(2),CCCallFunc::create(this, callfunc_selector(BattleMap::battle4Display)),NULL));
        arrow1->setVisible(true);arrow2->setVisible(true);
        battle2->setVisible(true);battle2_btn->setVisible(true);battle3->setVisible(true);battle3_btn->setVisible(true);
        arrow3->runAction(CCRepeatForever::create(CCBlink::create(2, 1)));
        yun1->setVisible(true);yun2->setVisible(true);yun3->setVisible(true);
    }
    if(choose==5){
        this->setPosition(ccp(240-battle4->getPositionX(),160-battle4->getPositionY()));
        this->runAction(CCSequence::create(CCMoveTo::create(8, ccp(240-battle5->getPositionX()-30,160-battle5->getPositionY()+50)),
                                           CCDelayTime::create(2),CCCallFunc::create(this, callfunc_selector(BattleMap::battle5Display)),NULL));
        arrow1->setVisible(true);arrow2->setVisible(true);arrow3->setVisible(true);
        battle2->setVisible(true);battle2_btn->setVisible(true);
        battle3->setVisible(true);battle3_btn->setVisible(true);
        battle4->setVisible(true);battle4_btn->setVisible(true);
        arrow4->runAction(CCRepeatForever::create(CCBlink::create(2, 1)));
        yun1->setVisible(true);yun2->setVisible(true);yun3->setVisible(true);yun4->setVisible(true);
    }
    if(choose>=6){
        this->setPosition(ccp(240-battle5->getPositionX()-30,160-battle5->getPositionY()+50));
        arrow1->setVisible(true);arrow2->setVisible(true);arrow3->setVisible(true);arrow4->setVisible(true);
        battle2->setVisible(true);battle2_btn->setVisible(true);battle3->setVisible(true);battle3_btn->setVisible(true);battle4->setVisible(true);
        battle4_btn->setVisible(true); battle5->setVisible(true);battle5_btn->setVisible(true);
        yun1->setVisible(true);yun2->setVisible(true);yun3->setVisible(true);yun4->setVisible(true);yun5->setVisible(true);
    }
    return true;
}

void BattleMap::battle2Display()
{
    battle2->setVisible(true);
    battle2_btn->setVisible(true);
}
void BattleMap::battle3Display()
{
    battle3->setVisible(true);
    battle3_btn->setVisible(true);
}
void BattleMap::battle4Display()
{
    battle4->setVisible(true);
    battle4_btn->setVisible(true);
}
void BattleMap::battle5Display()
{
    battle5->setVisible(true);
    battle5_btn->setVisible(true);
}
void BattleMap::goToBattle1()
{
    if (!CCUserDefault::sharedUserDefault()->getBoolForKey("storyMode") && CCUserDefault::sharedUserDefault()->getBoolForKey("moveEnable")) {
        CCUserDefault::sharedUserDefault()->setBoolForKey("moveEnable", false);
        float px=this->getPositionX()-240+battle1->getPositionX();
        float py=this->getPositionY()-160+battle1->getPositionY()+50;
        float longDis=sqrtf(px*px+py*py);
        this->runAction(CCSequence::create(CCMoveTo::create(longDis/100, ccp(240-battle1->getPositionX(),160-battle1->getPositionY()-50)),
                                           CCCallFunc::create(myHud, callfunc_selector(BattleMapHud::showBattle1Detail)),NULL));
    }
}
void BattleMap::goToBattle2()
{
    if (!CCUserDefault::sharedUserDefault()->getBoolForKey("storyMode") && CCUserDefault::sharedUserDefault()->getBoolForKey("moveEnable")) {
        CCUserDefault::sharedUserDefault()->setBoolForKey("moveEnable", false);
        float px=this->getPositionX()-240+battle2->getPositionX();
        float py=this->getPositionY()-160+battle2->getPositionY();
        float longDis=sqrtf(px*px+py*py);
        this->runAction(CCSequence::create(CCMoveTo::create(longDis/100, ccp(240-battle2->getPositionX(),160-battle2->getPositionY())),
                                           CCCallFunc::create(myHud, callfunc_selector(BattleMapHud::showBattle2Detail)),NULL));
    }
}
void BattleMap::goToBattle3()
{
    if (!CCUserDefault::sharedUserDefault()->getBoolForKey("storyMode") && CCUserDefault::sharedUserDefault()->getBoolForKey("moveEnable")) {
        CCUserDefault::sharedUserDefault()->setBoolForKey("moveEnable", false);
        float px=this->getPositionX()-240+battle3->getPositionX();
        float py=this->getPositionY()-160+battle3->getPositionY();
        float longDis=sqrtf(px*px+py*py);
        this->runAction(CCSequence::create(CCMoveTo::create(longDis/100, ccp(240-battle3->getPositionX(),160-battle3->getPositionY())),
                                           CCCallFunc::create(myHud, callfunc_selector(BattleMapHud::showBattle3Detail)),NULL));
    }
}
void BattleMap::goToBattle4()
{
    if (!CCUserDefault::sharedUserDefault()->getBoolForKey("storyMode") && CCUserDefault::sharedUserDefault()->getBoolForKey("moveEnable")) {
        CCUserDefault::sharedUserDefault()->setBoolForKey("moveEnable", false);
        float px=this->getPositionX()-240+battle4->getPositionX();
        float py=this->getPositionY()-160+battle4->getPositionY();
        float longDis=sqrtf(px*px+py*py);
        this->runAction(CCSequence::create(CCMoveTo::create(longDis/100, ccp(240-battle4->getPositionX(),160-battle4->getPositionY())),
                                           CCCallFunc::create(myHud, callfunc_selector(BattleMapHud::showBattle4Detail)),NULL));
    }
}
void BattleMap::goToBattle5()
{
    if (!CCUserDefault::sharedUserDefault()->getBoolForKey("storyMode") && CCUserDefault::sharedUserDefault()->getBoolForKey("moveEnable")) {
        CCUserDefault::sharedUserDefault()->setBoolForKey("moveEnable", false);
        float px=this->getPositionX()-240+battle5->getPositionX()+30;
        float py=this->getPositionY()-160+battle5->getPositionY()-50;
        float longDis=sqrtf(px*px+py*py);
        this->runAction(CCSequence::create(CCMoveTo::create(longDis/100, ccp(240-battle5->getPositionX()-30,160-battle5->getPositionY()+50)),
                                           CCCallFunc::create(myHud, callfunc_selector(BattleMapHud::showBattle5Detail)),NULL));
    }
}


