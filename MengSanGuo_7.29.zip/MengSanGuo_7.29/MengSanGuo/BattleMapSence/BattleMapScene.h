#ifndef __GroupWork_MSG__BattleScene__
#define __GroupWork_MSG__BattleScene__

#include <iostream>
#include "cocos2d.h"
#include "BattleMapHud.h"
#include "BattleMap.h"

using namespace cocos2d;
class BattleMapScene:public CCScene {
public:
    BattleMapScene();
    ~BattleMapScene();
    bool init();
    CREATE_FUNC(BattleMapScene);
    CC_SYNTHESIZE(BattleMapHud *, _hud, Hud);
    CC_SYNTHESIZE(BattleMap *, _gameLayer, GameLayer);
};
#endif /* defined(__GroupWork_MSG__BattleScene__) */