#include "BattleMapScene.h"

BattleMapScene::BattleMapScene()
{
    _hud = NULL;
    _gameLayer = NULL;
}

BattleMapScene::~BattleMapScene()
{
    
}

bool BattleMapScene:: init()
{
    bool bRet = false;
    do {
        CC_BREAK_IF(!CCScene::init());
        _hud = BattleMapHud::create();
        this->addChild(_hud,2);
        _gameLayer = BattleMap::create();
        this->addChild(_gameLayer,1);
        _hud->myLayer=_gameLayer;
        _gameLayer->myHud=_hud;
        bRet=true;
    } while (0);
    
    return bRet;
}
