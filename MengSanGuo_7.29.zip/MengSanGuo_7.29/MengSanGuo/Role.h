//
//  Role.h
//  Team
//
//  Created by naxx on 13-7-24.
//
//

#ifndef __Team__Role__
#define __Team__Role__

#include <iostream>
#include "cocos2d.h"
#include "cocos-ext.h"
USING_NS_CC;
USING_NS_CC_EXT;
class RoleTablelView:public CCLayer ,public CCTableViewDataSource,public CCTableViewDelegate
{
public:
    
    static CCScene *scene();
    virtual bool init();
    CREATE_FUNC(RoleTablelView);
    virtual void scrollViewDidScroll(cocos2d::extension::CCScrollView* view);
    virtual void scrollViewDidZoom(cocos2d::extension::CCScrollView* view);
    virtual CCSize cellSizeForTable(CCTableView *table) ;
    virtual CCTableViewCell* tableCellAtIndex(CCTableView *table, unsigned int idx);
    virtual unsigned int numberOfCellsInTableView(CCTableView *table);
    virtual void tableCellTouched(CCTableView* table, CCTableViewCell* cell);

};



#endif /* defined(__Team__Role__) */
