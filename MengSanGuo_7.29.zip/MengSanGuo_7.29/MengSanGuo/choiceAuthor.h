//
//  choiceAuthor.h
//  MengSanGuo
//
//  Created by 尚德机构 on 13-7-22.
//
//

#ifndef __MengSanGuo__choiceAuthor__
#define __MengSanGuo__choiceAuthor__

#include <iostream>
#include "cocos2d.h"
class choiceAuthor : public cocos2d::CCLayer
{
public:
    virtual bool init();
    static cocos2d::CCScene* scene();
    CREATE_FUNC(choiceAuthor);
    
private:
    void readAuthor();
    void makeNewAuthorIsPressed();
    void backMenu();
    void startGame();
    
};

#endif /* defined(__MengSanGuo__choiceAuthor__) */
