
//
//  score.cpp
//  MengSanGuo
//
//  Created by 尚德机构 on 13-7-18.
//
//

#include "score.h"
#include "cocos2d.h"
#include "HelloWorldScene.h"
#include "author.h"
using namespace cocos2d;

CCScene* score::scene()
{
    CCScene *scene = CCScene::create();
    score *layer = score::create();
    scene->addChild(layer);
    return scene;
}

bool score::init()
{
    if (!CCLayer::init()) {
        return false;
    }
    CCSize size = CCDirector::sharedDirector()->getWinSize();
    CCSprite* sp = CCSprite::create("scorebg.png");
    sp->setPosition(ccp(size.width/2.0f, size.height/2.0f));
    addChild(sp);
    
    //add a text
    std::string scoreStr = "";
    //get the score
    std::string score = CCUserDefault::sharedUserDefault()->getStringForKey("user_score","-1").c_str();
    //charge the score is the highest
    if (atoi(score.c_str())!=-1) {
        scoreStr += score;
    }
    else{
        scoreStr = "0";
    }
    CCLabelTTF* ttfScore = CCLabelTTF::create(scoreStr.c_str(), "Helvetica", 24);
    ttfScore->setPosition(ccp(size.width/2.0f-50, size.height/2.0f+40));
    ttfScore->setColor(ccc3(255, 0, 0));
    addChild(ttfScore);
    
    
 //add a buttun to change into the menu scene
    CCMenuItemImage *Itemquit = CCMenuItemImage::create( "back.png","back.png",this,menu_selector(score::backMenu));
    Itemquit->setPosition(ccp(40.0f, 40.0f));
    
 // create menu, it's an autorelease object
    CCMenu* pMenu = CCMenu::create(Itemquit, NULL);
    pMenu->setPosition( CCPointZero );
    this->addChild(pMenu, 1);
    
    
    CCTexture2D* texture = CCTextureCache::sharedTextureCache()->addImage("stars.png");
    CCParticleBatchNode* particleNode =CCParticleBatchNode::createWithTexture(texture);
    for (int i =0 ; i<3; i++) {
        CCParticleSystem* particleSyetem = CCParticleGalaxy::create();
        particleSyetem->setTexture(texture);
        particleSyetem->setPosition(ccp(400+i*20,290));
        particleNode->addChild(particleSyetem);
    }
    addChild(particleNode);
    
    return true;
}


void score::backMenu()
{
    CCDirector::sharedDirector()->replaceScene(CCTransitionPageTurn::create(0.5, HelloWorld::scene(), true));
}