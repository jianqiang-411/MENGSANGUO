//
//  help.h
//  MengSanGuo
//
//  Created by 尚德机构 on 13-7-18.
//
//

#ifndef __MengSanGuo__about__
#define __MengSanGuo__about__

#include <iostream>
#include "cocos2d.h"
class help : public cocos2d::CCLayer
{
public:
    virtual bool init();
    static cocos2d::CCScene* scene();
    CREATE_FUNC(help);
    
private:
    void authortMenu();
    void authorIsPressed();
    void backMenu();
   
};
#endif /* defined(__MengSanGuo__help__) */
