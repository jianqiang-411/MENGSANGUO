//
//  MSGWorld.cpp
//  Team
//
//  Created by naxx on 13-7-22.
//
//

#include "MSGWorld.h"

CCScene* MSGWorld::scene()
{
    
    

    CCScene *scene = CCScene::create();
    MSGWorld *layer = MSGWorld::create();
    
    scene->addChild(layer);
    const char *  name2= CCString::create(CCUserDefault::sharedUserDefault()->getStringForKey("name"))->getCString();

    CCLabelTTF *name1 = CCLabelTTF::create(name2, name2, 20);
    
    name1->setString(name2);
    name1->setPosition(ccp(100, 300));
    layer->addChild(name1,2);
  
    
    return scene;
}

MSGWorld::MSGWorld()
{
   
}
MSGWorld::~MSGWorld()
{
   
}
bool MSGWorld::init()
{
    bool pRet = false;
    do {
        CC_BREAK_IF(!CCLayer::init());
        CCSize size = CCDirector::sharedDirector()->getWinSize();
        
        this->shijianlan();
        CCLayer *floor = CCLayer::create();
        
        
        CCSprite * bg =CCSprite::create("bg12.png");
        bg->setAnchorPoint(CCPointZero);
        bg->setPosition(CCPointZero);
//        bg->setOpacity(0);
        floor->addChild(bg);
        
        CCLog("bg.width=%f,bg.height=%f",bg->getContentSize().width,bg->getContentSize().height);
        
        floor->setContentSize(CCSizeMake(bg->getContentSize().width, size.height));
        CCMenuItemImage *ItemImage = CCMenuItemImage::create("house1.png", "house1.png", this, menu_selector(MSGWorld::Zhuchengshengji));
        ItemImage->setScale(0.8f);
        
        
//        ItemImage->setPosition(ccp(size.width/4, size.height/size.height+70));
        
        CCMenuItemImage *ItemImage2 = CCMenuItemImage::create("house2.png", "house2.png", this, menu_selector(MSGWorld::Zhuchengshengji));
        
        
        CCMenu *menu = CCMenu::create(ItemImage,ItemImage2,NULL);
        menu->setPosition(ccp(size.width/3 , 80));
        menu->alignItemsHorizontallyWithPadding(40);
        floor->addChild(menu);
        
        CCScrollView *scrollView = CCScrollView::create(CCSizeMake(size.width, size.height));
        
        addChild(scrollView);
        scrollView->isDragging();
        scrollView->isTouchMoved();
        scrollView->setViewSize(CCSizeMake(size.width, size.height));
        scrollView->setContainer(floor);
        scrollView->setTouchEnabled(true);
        scrollView->setDelegate(this);
        scrollView->setDirection(kCCScrollViewDirectionHorizontal);
        scrollView->updateInset();
        
        
        
        
        
        
        
        pRet = true;
    } while (0);
    return pRet;
}
void MSGWorld::Zhuchengshengji()
{
        CCLOG("升级");
    
    
    
    
}
void MSGWorld::wujianglan()
{
    CCDirector::sharedDirector()->replaceScene(MilitaryCommandersPanel::scene());
   
}
void MSGWorld::shijianlan()
{
    CCMenuItemImage *Item  = CCMenuItemImage::create("wujiang.png", "wujiang.png", this,menu_selector(MSGWorld::wujianglan) );
    Item->setPosition(ccp(0, 0));
    CCMenuItemImage *Item2 = CCMenuItemImage::create("zhengzhan.png", "zhengzhan.png",this,menu_selector(MSGWorld::ZhengZhanLan));
    Item->setPosition(ccp(50, 0));
    CCMenu *menu = CCMenu::create(Item,Item2,NULL);
    menu->setPosition(ccp(CCDirector::sharedDirector()->getWinSize().width-100, 40));
    addChild(menu,2);
    
    CCLayer *layer2 = CCLayer::create();
    layer2->setPosition(ccp(20, CCDirector::sharedDirector()->getWinSize().height-20));
    
    
    
    
    CCSprite *touxian  = CCSprite::create("touxiang.png");
    touxian->setPosition(ccp(40, CCDirector::sharedDirector()->getWinSize().height-20));
    addChild(touxian,2);
    
   
    

}
void MSGWorld::ZhengZhanLan()
{
    CCDirector::sharedDirector()->replaceScene(BattleMapScene::create());
    
    
    
    
}
void MSGWorld::scrollViewDidScroll(cocos2d::extension::CCScrollView *view)
{
    
    
    
}
void MSGWorld::scrollViewDidZoom(cocos2d::extension::CCScrollView *view)
{
    
}