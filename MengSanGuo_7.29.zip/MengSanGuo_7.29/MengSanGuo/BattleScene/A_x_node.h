//
//  A_x_node.h
//  GroupWork_MSG
//
//  Created by 马梓元 on 13-7-25.
//
//

#ifndef __GroupWork_MSG__A_x_node__
#define __GroupWork_MSG__A_x_node__

#include <iostream>
#include "cocos2d.h"
using namespace cocos2d;
class A_x_node:public cocos2d::CCSprite
{
public:
    int x_num;
    int y_num;
    int F;
    int G;
    int H;
    A_x_node * parent;
    bool block;
    A_x_node();
    bool initWith(int _x_num,int _y_num);
    static A_x_node * creat(int _x_num,int _y_num);
    
//static A_x_node * creat(int _x_num,int _y_num);
};
#endif /* defined(__GroupWork_MSG__A_x_node__) */
