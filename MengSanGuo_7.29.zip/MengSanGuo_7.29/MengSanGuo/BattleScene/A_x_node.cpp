//
//  A_x_node.cpp
//  GroupWork_MSG
//
//  Created by 马梓元 on 13-7-25.
//
//

#include "A_x_node.h"
A_x_node:: A_x_node()
{

    x_num=0;
    y_num=0;
    parent=NULL;
    F=999;
    G=999;
    H=999;
    block=false;
    
    
}

 A_x_node * A_x_node:: creat(int _x_num,int _y_num)
{
    A_x_node * pRet =new A_x_node();
    if (pRet&&pRet->initWith(_x_num, _y_num)) {
        pRet->autorelease();
        return pRet;
    }
    else
    
    {
        delete pRet;
        pRet=NULL;
        return NULL;
    
    }

}

bool A_x_node:: initWith(int _x_num,int _y_num)
{
    bool pRet =false;
    
    do {
        CC_BREAK_IF(!CCSprite::initWithFile("box-1.png"));
        
        x_num=_x_num;
        y_num=_y_num;
        
        pRet=true;
        
        
    } while (0);


    return pRet;


}