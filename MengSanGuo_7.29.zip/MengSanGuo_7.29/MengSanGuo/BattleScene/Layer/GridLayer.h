//
//  Grid.h
//  GroupWork_MSG
//
//  Created by S-xy on 13-7-10.
//
//

#ifndef __GroupWork_MSG__GridLayer__
#define __GroupWork_MSG__GridLayer__

#include <iostream>
    #include "cocos2d.h"
#include "A_x_node.h"
using namespace cocos2d;

class GridLayer:public CCLayer {
    
    
public:
    bool init();
    void draw();
    CCSpriteBatchNode *  _actors;
    CC_SYNTHESIZE(CCArray *, _nodes, Nodes);
    CCArray * findShortestRoute(A_x_node * start,A_x_node * end);
CREATE_FUNC(GridLayer);
    
    A_x_node * findLowestFNode(CCArray * openArr);
    CCArray * finalArr = CCArray::createWithCapacity(50);
    A_x_node * currentNode = NULL;
    CCArray * openArr = CCArray::createWithCapacity(50);
    CCArray * closeArr = CCArray::createWithCapacity(50);
    CCArray * allNodesArr = CCArray::createWithCapacity(50);
    
};
#endif /* defined(__GroupWork_MSG__Grid__) */
