//
//  GridLayer.cpp
//  GroupWork_MSG
//
//  Created by S-xy on 13-7-10.
//
//

#include "GridLayer.h"
#include "Define.h"
#include "ActionSprite.h"
using namespace cocos2d;
bool GridLayer:: init()
{
    bool bRet = false;
    do {
        
        CC_BREAK_IF(!CCLayer::init());
      
//        this->scheduleUpdate();
     
        
        
        bRet=true;
    } while (0);
//     this->draw();
     
    _nodes=CCArray::createWithCapacity(50);
    for (int i =0; i<45; i++) {
        A_x_node * temp = A_x_node::creat(i%9, i/9);
        allNodesArr->addObject(temp);
    }
    
    return bRet;



}

void GridLayer:: draw()
{

    for (int i = 0; i<GRID_ROW_NUM+1; i++) {
        
        
        ccDrawLine(ccp(GRID_EDGE, GRID_BOTTOM+GRID_WIDTH*i), ccp(GRID_EDGE+GRID_COLUMN_NUM*GRID_WIDTH,GRID_BOTTOM+GRID_WIDTH*i));
    }
    for (int i = 0; i<GRID_COLUMN_NUM+1; i++) {
        
        
        ccDrawLine(ccp(GRID_EDGE+GRID_WIDTH*i, GRID_BOTTOM), ccp(GRID_EDGE+GRID_WIDTH*i,GRID_BOTTOM+GRID_WIDTH*GRID_ROW_NUM));
    }
 
}

CCArray * GridLayer:: findShortestRoute(A_x_node * start,A_x_node * end)
{
    start->G=0;
    start->F=0;
    
    openArr->addObject(start);
    while (0) {
        A_x_node * lowestNode = this->findLowestFNode(openArr);
        currentNode = lowestNode;
        if (currentNode) {
            openArr->removeObject(currentNode);
            closeArr->addObject(currentNode);
        }
        if (currentNode->y_num>=1) {
             A_x_node * upNode = (A_x_node*)allNodesArr->objectAtIndex(currentNode->x_num+(currentNode->y_num-1)*9);
            //如果节点不可通行或者该节点已经在封闭列表中，不执行操作，继续下一节点
            if ((!upNode->block)||(!closeArr->containsObject(upNode))) {
                //如果不在开放列表中，则将节点添加到开放列表中，并将相邻节点父节点设置为当前节点，保存该节点G和F值
                if (!openArr->containsObject(upNode)) {
                    openArr->addObject(upNode);
                    upNode->parent = currentNode;
                    
                }
                
                
                
                
            }
            
        }
       
        
        
    }




    return finalArr;
}

A_x_node * GridLayer::findLowestFNode(CCArray * openArr)
{
    A_x_node * temp =NULL;
    A_x_node * min_node = NULL;
    int F_min=999;
    for (int i = 0; i< openArr->count(); i++) {
        temp=(A_x_node*)openArr->objectAtIndex(i);
        if (temp->G<F_min) {
            F_min=temp->G;
            min_node= temp;
        }
        
    }
    return min_node;
}