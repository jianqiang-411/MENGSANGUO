//
//  lb.h
//  GroupWork_MSG
//
//  Created by 马梓元 on 13-7-21.
//
//

#ifndef __GroupWork_MSG__lb__
#define __GroupWork_MSG__lb__

#include <iostream>
#include "cocos2d.h"
#include "ActionSprite.h"
using namespace cocos2d;
class lb: public ActionSprite
{
    
public:
    CREATE_FUNC(lb);
    bool init();
    
};
#endif /* defined(__GroupWork_MSG__lb__) */
