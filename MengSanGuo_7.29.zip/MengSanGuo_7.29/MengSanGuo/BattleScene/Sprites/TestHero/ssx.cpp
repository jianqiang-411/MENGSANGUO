//
//  ssx.cpp
//  GroupWork_MSG
//
//  Created by 马梓元 on 13-7-21.
//
//

#include "Ssx.h"
#include "Actions.h"
bool ssx:: init()
{
    bool Rbet = false;
    do {
        CC_BREAK_IF(!ActionSprite:: init());
        
        this->setFactory(Actions::create());
        this->getFactory()->retain();
        this->setNegativeAttackAction(this->getFactory()->creatWalkAction("ssx_" , 9,12));
        this->getNegativeAttackAction()-> retain();
        this->setWalkAction(this->getFactory()->creatWalkAction("ssx_" , 5,8));
        
        this->getWalkAction()->retain();
        this->setAttackAction(this->getFactory()->creatAttackAction("ssx_melee_",9,12));
        this->getAttackAction()->retain();
        
        this->setNegativeAttackAction(this->getFactory()->creatAttackAction("ssx_melee_", 5, 8));
        this->getNegativeAttackAction()->retain();
          Rbet = true;
    } while (0);
    return Rbet;
}

