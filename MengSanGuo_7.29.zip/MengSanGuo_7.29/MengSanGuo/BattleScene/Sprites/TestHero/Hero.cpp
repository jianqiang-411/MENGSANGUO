//
//  Hero.cpp
//  GroupWork_MSG
//
//  Created by 马梓元 on 13-7-21.
//
//

#include "Hero.h"
#include "Actions.h"
bool Hero:: initWithFile(const char * filename)
{
    bool Rbet = false;
    do {
        CC_BREAK_IF(!ActionSprite:: init());
        
        this->setFactory(Actions::create());
        this->getFactory()->retain();
        
        this->setNegativeAttackAction(this->getFactory()->creatWalkAction(CCString::createWithFormat("%s_",filename)->getCString(), 9,12));
        this->getNegativeAttackAction()-> retain();
        this->setWalkAction(this->getFactory()->creatWalkAction(CCString::createWithFormat("%s_",filename)->getCString() , 5,8));
        
        this->getWalkAction()->retain();
        this->setAttackAction(this->getFactory()->creatAttackAction(CCString::createWithFormat("%s_melee_",filename)->getCString(),9,12));
        this->getAttackAction()->retain();
        
        this->setNegativeAttackAction(this->getFactory()->creatAttackAction(CCString::createWithFormat("%s_melee_",filename)->getCString(), 5, 8));
        this->getNegativeAttackAction()->retain();
        Rbet = true;
    } while (0);
    return Rbet;
}