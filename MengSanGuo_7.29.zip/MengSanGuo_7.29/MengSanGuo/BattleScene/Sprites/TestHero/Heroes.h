//
//  heroes.h
//  GroupWork_MSG
//
//  Created by 马梓元 on 13-7-21.
//
//

#ifndef GroupWork_MSG_heroes_h
#define GroupWork_MSG_heroes_h

#include "ssx.h"
#include "lb.h"

#endif
