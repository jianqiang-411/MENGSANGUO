//
//  ssx.h
//  GroupWork_MSG
//
//  Created by 马梓元 on 13-7-21.
//
//

#ifndef __GroupWork_MSG__ssx__
#define __GroupWork_MSG__ssx__

#include <iostream>
#include "cocos2d.h"
#include "ActionSprite.h"
using namespace cocos2d;
class ssx: public ActionSprite {
    
public:
    CREATE_FUNC(ssx);
    bool init();

};

#endif /* defined(__GroupWork_MSG__ssx__) */
