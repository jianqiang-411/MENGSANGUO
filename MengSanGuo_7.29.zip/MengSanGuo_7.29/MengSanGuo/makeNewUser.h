//
//  makeNewUser.h
//  MengSanGuo
//
//  Created by 尚德机构 on 13-7-19.



#ifndef __MengSanGuo__makeNewUser__
#define __MengSanGuo__makeNewUser__

#include "cocos2d.h"
#include "cocos-ext.h"
using namespace cocos2d::extension;

class makeNewUser : public cocos2d::CCLayer ,public cocos2d:: extension::CCEditBoxDelegate
{
public:
    virtual bool init();
    static cocos2d::CCScene* scene();
    CREATE_FUNC(makeNewUser);
    
    //开始进入编辑
    virtual void editBoxEditingDidBegin(cocos2d::extension::CCEditBox* editBox);
    //结束编辑
    virtual void editBoxEditingDidEnd(cocos2d::extension::CCEditBox* editBox);
    //编辑框文本改变
    virtual void editBoxTextChanged(cocos2d::extension::CCEditBox* editBox, const std::string& text);
    //当触发return后的回调函数
    virtual void editBoxReturn(cocos2d::extension::CCEditBox* editBox);
    

private:
     void sureIsPressed();
     void backMenu();
};
#endif /* defined(__MengSanGuo__makeNewUser__) */
