//
//  score.h
//  MengSanGuo
//
//  Created by 尚德机构 on 13-7-18.
//
//

#ifndef __MengSanGuo__score__
#define __MengSanGuo__score__

#include <iostream>
#include "cocos2d.h"
class score : public cocos2d::CCLayer
{
public:
    virtual bool init();
    static cocos2d:: CCScene* scene();
    CREATE_FUNC(score);
private:
    void backMenu();
};

#endif /* defined(__MengSanGuo__score__) */
