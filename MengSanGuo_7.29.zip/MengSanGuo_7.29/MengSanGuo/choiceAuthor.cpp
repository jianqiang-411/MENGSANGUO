//
//  choiceAuthor.cpp
//  MengSanGuo
//
//  Created by 尚德机构 on 13-7-22.
//
//

#include "choiceAuthor.h"
#include "HelloWorldScene.h"
#include "makeNewUser.h"

using namespace cocos2d;

CCScene* choiceAuthor::scene()
{
    CCScene *scene = CCScene::create();
    choiceAuthor *layer = choiceAuthor::create();
    scene->addChild(layer);
    return scene;
}

bool choiceAuthor::init()
{
    if (!CCLayer::init()) {
        return false;
    }
    //get the screen size
    CCSize size = CCDirector::sharedDirector()->getWinSize();
    //background
    CCSprite* sp = CCSprite::create("choiceAuthor.png");
    sp->setPosition(ccp(size.width/2.0f, size.height/2.0f));
    addChild(sp);
    
    
    
    
     
 //add a buttun to change into the menu scene
    CCMenuItemImage *Itemquit = CCMenuItemImage::create( "back.png","back.png",this,menu_selector(choiceAuthor::backMenu));
    Itemquit->setPosition(ccp(40.0f, 40.0f));
    
 // create menu, it's an autorelease object
    CCMenu* pMenu = CCMenu::create(Itemquit, NULL);
    pMenu->setPosition( CCPointZero );
    this->addChild(pMenu, 1);
    
    
    
    
 //create the menu for makeing author
    CCLabelTTF* labelRead  =CCLabelTTF::create("读取存档", "Helvetica-Bold", 23);
    labelRead->setColor(ccc3(255, 0, 0));
    CCMenuItemLabel* menuLabel1= CCMenuItemLabel::create(labelRead, this, menu_selector(choiceAuthor::makeNewAuthorIsPressed));
    menuLabel1->setPosition(ccp(240,220));
    pMenu->addChild(menuLabel1);

    CCLabelTTF* labelMakeNewAuthor  =CCLabelTTF::create("创建新的角色", "Helvetica-Bold", 23);
    labelMakeNewAuthor->setColor(ccc3(0, 0, 255));
    CCMenuItemLabel* menuLabel= CCMenuItemLabel::create(labelMakeNewAuthor, this, menu_selector(choiceAuthor::makeNewAuthorIsPressed));
    menuLabel->setPosition(ccp(240,160));
    pMenu->addChild(menuLabel);
    
    
    
    CCTexture2D* texture = CCTextureCache::sharedTextureCache()->addImage("fire.png");
    CCParticleBatchNode* particleNode =CCParticleBatchNode::createWithTexture(texture);
    for (int i =0 ; i<3; i++) {
        CCParticleSystem* particleSyetem = CCParticleFire::create();
        particleSyetem->setTexture(texture);
        particleSyetem->setPosition(ccp(0+i*20,0));
        particleNode->addChild(particleSyetem);
    }
    for (int i =0 ; i<3; i++) {
        CCParticleSystem* particleSyetem = CCParticleFire::create();
        particleSyetem->setTexture(texture);
        particleSyetem->setPosition(ccp(450+i*20,0));
        particleNode->addChild(particleSyetem);
    }
    
    
    addChild(particleNode);
    
    
    
    
    return true;
}

//change into play scene
void choiceAuthor::makeNewAuthorIsPressed() {
    CCDirector::sharedDirector()->replaceScene(CCTransitionFadeDown::create(0.5, makeNewUser::scene()));
}
//游戏开始接口
void choiceAuthor:: startGame() {
    CCDirector::sharedDirector()->replaceScene(CCTransitionFadeBL::create(0.5, HelloWorld::scene()));
}


void choiceAuthor::backMenu()
{
    CCDirector::sharedDirector()->replaceScene(CCTransitionPageTurn::create(0.5, HelloWorld::scene(), true));
}